-- 1) Admin list
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);

alter table public.admins enable row level security;

-- 2) Helper function to check admin
create or replace function public.is_admin(uid uuid)
returns boolean
language sql
stable
as $$
  select exists (
    select 1 from public.admins a
    where a.user_id = uid
  );
$$;

grant execute on function public.is_admin(uuid) to authenticated;

-- 3) RLS: admins can read the admin list (optional)
create policy "admins can read admins"
on public.admins
for select
to authenticated
using (public.is_admin(auth.uid()));

-- 4) RLS: only admins can modify admin list (optional, keep for later)
create policy "admins can manage admins"
on public.admins
for all
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));