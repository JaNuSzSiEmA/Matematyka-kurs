import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useRouter } from 'next/router';
import Link from 'next/link';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

export default function CoursePage() {
  const router = useRouter();
  const { course_id } = router.query;

  const [checking, setChecking] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [userEmail, setUserEmail] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    let cancelled = false;

    async function run() {
      if (!course_id) return;

      setChecking(true);
      setErrorMsg('');

      try {
        const { data: { session }, error } = await supabase.auth.getSession();
        if (error) console.error('getSession error', error);

        if (!session) {
          if (!cancelled) {
            setUserEmail(null);
            setHasAccess(false);
          }
          return;
        }

        if (!cancelled) setUserEmail(session.user?.email ?? null);

        const res = await fetch(`/api/has-access?course_id=${encodeURIComponent(course_id)}`, {
          headers: { Authorization: `Bearer ${session.access_token}` },
        });

        const json = await res.json().catch(() => ({}));

        if (!res.ok) {
          if (!cancelled) {
            setHasAccess(false);
            setErrorMsg(json.error || `has-access failed (HTTP ${res.status})`);
          }
          return;
        }

        if (!cancelled) setHasAccess(Boolean(json.access));
      } catch (e) {
        if (!cancelled) {
          setHasAccess(false);
          setErrorMsg(e.message || String(e));
        }
      } finally {
        if (!cancelled) setChecking(false);
      }
    }

    run();
    return () => {
      cancelled = true;
    };
  }, [course_id]);

  if (checking) return <div style={{ padding: 24 }}>Checking access...</div>;

  if (errorMsg) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Error checking access</h1>
        <pre style={{ whiteSpace: 'pre-wrap' }}>{errorMsg}</pre>
        <p>Open DevTools → Network and check /api/has-access response.</p>
        <Link href="/login">Go to login</Link>
      </div>
    );
  }

  if (!userEmail) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Please sign in</h1>
        <Link href="/login">Go to login</Link>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Access denied</h1>
        <p>Signed in as: {userEmail}</p>
      </div>
    );
  }

  return (
    <div style={{ padding: 24 }}>
      <h1>Course: {course_id}</h1>
      <p>Welcome — you have access!</p>
    </div>
  );
}