import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import AdminGate from '../../../components/admin/AdminGate';
import { supabase } from '../../../lib/admin';

function safeJsonParse(str) {
  try {
    return { ok: true, value: JSON.parse(str) };
  } catch (e) {
    return { ok: false, error: e?.message || 'Invalid JSON' };
  }
}

function hintsFromTextarea(text) {
  const lines = String(text || '')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  return lines.length ? lines : null;
}

export default function AdminIslandEditor() {
  const router = useRouter();
  const { island_id } = router.query;

  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [island, setIsland] = useState(null); // includes section_id
  const [section, setSection] = useState(null); // includes course_id
  const [items, setItems] = useState([]);

  const [exercises, setExercises] = useState([]);
  const [exerciseSearch, setExerciseSearch] = useState('');

  // Add item form (video/exercise attach existing)
  const [newItem, setNewItem] = useState({
    item_type: 'video',
    title: '',
    youtube_url: '',
    exercise_id: '',
  });

  // Create & attach exercise form
  const [create, setCreate] = useState({
    prompt: '',
    description: '',
    image_url: '',
    answer_type: 'abcd',
    // for abcd we store { correct: "A" } (simple)
    // for numeric we store { value: 42 } (simple)
    answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
    points_max: 1,
    difficulty: 1,
    requires_ai: false,
    requires_photo: false,
    status: 'draft',
    solution_video_url: '',
    hints_text: '',
    // flags
    use_in_course: true,
    use_in_repertory: false,
    use_in_generator: false,
    use_in_minigame: false,
    // topic defaults to island.section_id (A)
    topic_section_id: '',
  });

  async function load() {
    if (!island_id) return;
    setLoading(true);
    setMsg('');

    const { data: isl, error: islErr } = await supabase
      .from('islands')
      .select('id, section_id, title, type, order_index, max_points, is_active')
      .eq('id', island_id)
      .single();

    if (islErr) {
      setMsg(islErr.message);
      setLoading(false);
      return;
    }
    setIsland(isl);

    const { data: sec, error: secErr } = await supabase
      .from('sections')
      .select('id, course_id, title, slug')
      .eq('id', isl.section_id)
      .single();

    if (secErr) {
      setMsg(`Load section failed: ${secErr.message}`);
      setLoading(false);
      return;
    }
    setSection(sec);

    // default topic_section_id = island.section_id
    setCreate((p) => ({
      ...p,
      topic_section_id: p.topic_section_id || isl.section_id,
    }));

    const { data: it, error: itErr } = await supabase
      .from('island_items')
      .select('id, island_id, item_type, order_index, title, youtube_url, exercise_id, created_at')
      .eq('island_id', island_id)
      .order('order_index', { ascending: true });

    if (itErr) {
      setMsg(itErr.message);
      setItems([]);
      setLoading(false);
      return;
    }
    setItems(it || []);

    // Load exercises (limit; you can expand later)
    const { data: ex, error: exErr } = await supabase
      .from('exercises')
      .select('id, prompt, answer_type, points_max, course_id, difficulty, status, use_in_course, use_in_repertory, use_in_generator, use_in_minigame, topic_section_id')
      .order('created_at', { ascending: false })
      .limit(500);

    if (exErr) {
      setMsg(`Load exercises failed: ${exErr.message}`);
      setExercises([]);
      setLoading(false);
      return;
    }

    setExercises(ex || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [island_id]);

  const filteredExercises = useMemo(() => {
    const term = exerciseSearch.trim().toLowerCase();
    if (!term) return exercises;

    return exercises.filter((e) => {
      const hay = `${e.prompt || ''} ${e.course_id || ''} ${e.answer_type || ''} ${e.id}`.toLowerCase();
      return hay.includes(term);
    });
  }, [exercises, exerciseSearch]);

  async function addVideoItem() {
    setMsg('');
    const order_index = (items?.length || 0) + 1;

    const { error } = await supabase.from('island_items').insert({
      island_id,
      item_type: 'video',
      order_index,
      title: newItem.title || null,
      youtube_url: newItem.youtube_url || null,
      exercise_id: null,
    });

    if (error) {
      setMsg(error.message);
      return;
    }

    setNewItem({ item_type: 'video', title: '', youtube_url: '', exercise_id: '' });
    await load();
  }

  async function addExistingExerciseItem() {
    setMsg('');
    const order_index = (items?.length || 0) + 1;

    if (!newItem.exercise_id) {
      setMsg('Wybierz exercise.');
      return;
    }

    const { error } = await supabase.from('island_items').insert({
      island_id,
      item_type: 'exercise',
      order_index,
      title: newItem.title || null,
      youtube_url: null,
      exercise_id: newItem.exercise_id,
    });

    if (error) {
      setMsg(error.message);
      return;
    }

    setNewItem({ item_type: 'video', title: '', youtube_url: '', exercise_id: '' });
    await load();
  }

  async function deleteItem(id) {
    setMsg('');
    const ok = window.confirm('Usunąć element?');
    if (!ok) return;

    const { error } = await supabase.from('island_items').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  async function createExerciseAndAttach() {
    setMsg('');
    if (!section?.course_id) {
      setMsg('Brak course_id (nie udało się wczytać sekcji).');
      return;
    }

    if (!create.prompt.trim()) {
      setMsg('Prompt jest wymagany.');
      return;
    }

    const parsed = safeJsonParse(create.answer_key_json);
    if (!parsed.ok) {
      setMsg(`answer_key JSON error: ${parsed.error}`);
      return;
    }

    const hints = hintsFromTextarea(create.hints_text);

    // 1) create exercise
    const { data: inserted, error: insErr } = await supabase
      .from('exercises')
      .insert({
        course_id: String(section.course_id),
        section_id: section.id, // keep your existing column: ties it to the branch too
        topic_section_id: create.topic_section_id ? String(create.topic_section_id) : null,
        prompt: create.prompt,
        description: create.description || null,
        image_url: create.image_url || null,
        answer_type: create.answer_type,
        points_max: Number(create.points_max),
        difficulty: Number(create.difficulty),
        requires_ai: Boolean(create.requires_ai),
        requires_photo: Boolean(create.requires_photo),
        status: create.status,
        solution_video_url: create.solution_video_url || null,
        hints,
        // flags
        use_in_course: Boolean(create.use_in_course),
        use_in_repertory: Boolean(create.use_in_repertory),
        use_in_generator: Boolean(create.use_in_generator),
        use_in_minigame: Boolean(create.use_in_minigame),
      })
      .select('id')
      .single();

    if (insErr) {
      setMsg(insErr.message);
      return;
    }

    // 2) create answer key
    const { error: keyErr } = await supabase.from('exercise_answer_keys').insert({
      exercise_id: inserted.id,
      answer_key: parsed.value,
    });

    if (keyErr) {
      setMsg(`Exercise created, but answer key insert failed: ${keyErr.message}`);
      await load();
      return;
    }

    // 3) attach to island
    const order_index = (items?.length || 0) + 1;
    const { error: itemErr } = await supabase.from('island_items').insert({
      island_id,
      item_type: 'exercise',
      order_index,
      title: null,
      youtube_url: null,
      exercise_id: inserted.id,
    });

    if (itemErr) {
      setMsg(`Exercise created, but island item insert failed: ${itemErr.message}`);
      await load();
      return;
    }

    // reset create form (keep defaults)
    setCreate((p) => ({
      ...p,
      prompt: '',
      description: '',
      image_url: '',
      answer_type: 'abcd',
      answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
      points_max: 1,
      difficulty: 1,
      requires_ai: false,
      requires_photo: false,
      status: 'draft',
      solution_video_url: '',
      hints_text: '',
      // keep flags as-is so you can mass-enter the same category
      topic_section_id: section.id, // default A
    }));

    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-6xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <Link
                href={island?.section_id ? `/admin/sections/${island.section_id}/islands` : '/admin/sections'}
                className="text-sm font-semibold text-gray-700 underline"
              >
                ← Wyspy
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Zawartość wyspy</h1>
              <p className="mt-1 text-sm text-gray-600">
                {section ? (
                  <>
                    Sekcja: <b>{section.title}</b> (<code>{section.slug}</code>) • course_id: <code>{section.course_id}</code>
                  </>
                ) : (
                  '—'
                )}
              </p>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          {loading ? (
            <div className="mt-6 text-sm text-gray-700">Ładowanie…</div>
          ) : (
            <div className="mt-6 grid gap-4 lg:grid-cols-3">
              {/* ITEMS LIST */}
              <div className="rounded-2xl border border-gray-200 p-4 lg:col-span-1">
                <div className="font-semibold text-gray-900">Elementy</div>

                {items.length === 0 ? (
                  <div className="mt-3 text-sm text-gray-600">Brak elementów.</div>
                ) : (
                  <div className="mt-3 space-y-3">
                    {items.map((it) => (
                      <div key={it.id} className="rounded-xl border border-gray-200 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <div className="text-sm text-gray-900">
                            <b>{it.order_index}.</b> <code>{it.item_type}</code>{' '}
                            {it.title ? <>• {it.title}</> : null}
                          </div>
                          <button
                            type="button"
                            className="rounded-lg border border-red-700 bg-red-700 px-3 py-1 text-sm font-semibold text-white"
                            onClick={() => deleteItem(it.id)}
                          >
                            Usuń
                          </button>
                        </div>

                        {it.item_type === 'video' ? (
                          <div className="mt-2 text-xs text-gray-700">
                            youtube_url: <code>{it.youtube_url || '—'}</code>
                          </div>
                        ) : (
                          <div className="mt-2 text-xs text-gray-700">
                            exercise_id: <code>{it.exercise_id || '—'}</code>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* ADD VIDEO / ATTACH EXISTING */}
              <div className="rounded-2xl border border-gray-200 p-4 lg:col-span-1">
                <div className="font-semibold text-gray-900">Dodaj video / podepnij ćwiczenie</div>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">title (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={newItem.title}
                    onChange={(e) => setNewItem((p) => ({ ...p, title: e.target.value }))}
                  />
                </label>

                <div className="mt-4 rounded-xl border border-gray-100 p-3">
                  <div className="text-sm font-semibold text-gray-900">Video</div>
                  <label className="mt-2 block">
                    <div className="text-xs font-semibold text-gray-600">youtube_url</div>
                    <input
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      placeholder="https://www.youtube.com/watch?v=..."
                      value={newItem.youtube_url}
                      onChange={(e) => setNewItem((p) => ({ ...p, youtube_url: e.target.value }))}
                    />
                  </label>
                  <button
                    type="button"
                    className="mt-3 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                    onClick={addVideoItem}
                  >
                    Dodaj video
                  </button>
                </div>

                <div className="mt-4 rounded-xl border border-gray-100 p-3">
                  <div className="text-sm font-semibold text-gray-900">Podepnij istniejące ćwiczenie</div>

                  <input
                    className="mt-2 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    placeholder="Szukaj w prompt…"
                    value={exerciseSearch}
                    onChange={(e) => setExerciseSearch(e.target.value)}
                  />

                  <select
                    className="mt-2 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={newItem.exercise_id}
                    onChange={(e) => setNewItem((p) => ({ ...p, exercise_id: e.target.value }))}
                  >
                    <option value="">— wybierz —</option>
                    {filteredExercises.map((e) => (
                      <option key={e.id} value={e.id}>
                        {e.status} • {e.answer_type} • {e.points_max}pkt • {String(e.prompt || '').slice(0, 70)}
                      </option>
                    ))}
                  </select>

                  <button
                    type="button"
                    className="mt-3 rounded-xl border border-indigo-700 bg-indigo-700 px-4 py-2 text-sm font-semibold text-white"
                    onClick={addExistingExerciseItem}
                  >
                    Podepnij ćwiczenie
                  </button>
                </div>
              </div>

              {/* CREATE & ATTACH */}
              <div className="rounded-2xl border border-gray-200 p-4 lg:col-span-1">
                <div className="font-semibold text-gray-900">Utwórz ćwiczenie + podepnij</div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <label>
                    <div className="text-xs font-semibold text-gray-600">answer_type</div>
                    <select
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      value={create.answer_type}
                      onChange={(e) => setCreate((p) => ({ ...p, answer_type: e.target.value }))}
                    >
                      <option value="abcd">abcd</option>
                      <option value="numeric">numeric</option>
                    </select>
                  </label>

                  <label>
                    <div className="text-xs font-semibold text-gray-600">status</div>
                    <select
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      value={create.status}
                      onChange={(e) => setCreate((p) => ({ ...p, status: e.target.value }))}
                    >
                      <option value="draft">draft</option>
                      <option value="published">published</option>
                      <option value="archived">archived</option>
                    </select>
                  </label>

                  <label>
                    <div className="text-xs font-semibold text-gray-600">points_max</div>
                    <input
                      type="number"
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      value={create.points_max}
                      onChange={(e) => setCreate((p) => ({ ...p, points_max: e.target.value }))}
                    />
                  </label>

                  <label>
                    <div className="text-xs font-semibold text-gray-600">difficulty</div>
                    <input
                      type="number"
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      value={create.difficulty}
                      onChange={(e) => setCreate((p) => ({ ...p, difficulty: e.target.value }))}
                    />
                  </label>
                </div>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">Prompt</div>
                  <textarea
                    className="mt-1 min-h-[110px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.prompt}
                    onChange={(e) => setCreate((p) => ({ ...p, prompt: e.target.value }))}
                  />
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">description (optional)</div>
                  <textarea
                    className="mt-1 min-h-[80px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.description}
                    onChange={(e) => setCreate((p) => ({ ...p, description: e.target.value }))}
                  />
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">image_url (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.image_url}
                    onChange={(e) => setCreate((p) => ({ ...p, image_url: e.target.value }))}
                  />
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">solution_video_url (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.solution_video_url}
                    onChange={(e) => setCreate((p) => ({ ...p, solution_video_url: e.target.value }))}
                  />
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">hints (one per line)</div>
                  <textarea
                    className="mt-1 min-h-[90px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.hints_text}
                    onChange={(e) => setCreate((p) => ({ ...p, hints_text: e.target.value }))}
                    placeholder={`Np.\nUprość wyrażenie\nPodstaw x=...`}
                  />
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">answer_key (JSON)</div>
                  <textarea
                    className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 font-mono text-xs"
                    value={create.answer_key_json}
                    onChange={(e) => setCreate((p) => ({ ...p, answer_key_json: e.target.value }))}
                  />
                  <div className="mt-1 text-xs text-gray-500">
                    abcd: <code>{`{ "correct": "A" }`}</code> • numeric: <code>{`{ "value": 42 }`}</code>
                  </div>
                </label>

                <div className="mt-3 grid gap-2">
                  <div className="text-xs font-semibold text-gray-600">Flags</div>
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.use_in_course)}
                      onChange={(e) => setCreate((p) => ({ ...p, use_in_course: e.target.checked }))}
                    />
                    use_in_course
                  </label>
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.use_in_repertory)}
                      onChange={(e) => setCreate((p) => ({ ...p, use_in_repertory: e.target.checked }))}
                    />
                    use_in_repertory
                  </label>
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.use_in_generator)}
                      onChange={(e) => setCreate((p) => ({ ...p, use_in_generator: e.target.checked }))}
                    />
                    use_in_generator
                  </label>
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.use_in_minigame)}
                      onChange={(e) => setCreate((p) => ({ ...p, use_in_minigame: e.target.checked }))}
                    />
                    use_in_minigame
                  </label>
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.requires_ai)}
                      onChange={(e) => setCreate((p) => ({ ...p, requires_ai: e.target.checked }))}
                    />
                    requires_ai
                  </label>

                  <label className="flex items-center gap-2 text-sm text-gray-700">
                    <input
                      type="checkbox"
                      checked={Boolean(create.requires_photo)}
                      onChange={(e) => setCreate((p) => ({ ...p, requires_photo: e.target.checked }))}
                    />
                    requires_photo
                  </label>
                </div>

                <button
                  type="button"
                  className="mt-4 w-full rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                  onClick={createExerciseAndAttach}
                >
                  Utwórz i podepnij do wyspy
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminGate>
  );
}