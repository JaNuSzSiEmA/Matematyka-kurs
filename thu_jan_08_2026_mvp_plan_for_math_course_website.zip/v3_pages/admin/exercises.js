import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AdminGate from '../../components/admin/AdminGate';
import { supabase } from '../../lib/admin';

function safeJsonParse(str) {
  try {
    return { ok: true, value: JSON.parse(str) };
  } catch (e) {
    return { ok: false, error: e?.message || 'Invalid JSON' };
  }
}

function getCourseLabel(c) {
  // Works with many schemas: title/name/slug/course_id
  return c?.title || c?.name || c?.slug || c?.course_id || c?.id || 'course';
}

export default function AdminExercises() {
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [courses, setCourses] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [answerKeysByExerciseId, setAnswerKeysByExerciseId] = useState({}); // { [exerciseId]: json }

  // Create form (includes REQUIRED fields)
  const [create, setCreate] = useState({
    course_id: '',
    prompt: '',
    answer_type: 'abcd',
    points_max: 1,
    difficulty: 1,
    requires_ai: false,
    requires_photo: false,
    image_url: '',
    answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
  });

  // Filter
  const [q, setQ] = useState('');

  async function load() {
    setLoading(true);
    setMsg('');

    // Load courses first (so dropdown works)
    const { data: courseRows, error: courseErr } = await supabase
      .from('courses')
      .select('*')
      .order('created_at', { ascending: true });

    if (courseErr) {
      setMsg(`Load courses failed: ${courseErr.message}`);
      setCourses([]);
    } else {
      setCourses(courseRows || []);
      // if not chosen yet, default to first course (if present)
      if (!create.course_id && (courseRows || []).length > 0) {
        const first = courseRows[0];
        // Your exercises.course_id is TEXT; many projects store courses.course_id text too.
        // Prefer courses.course_id, else fallback to courses.id (stringified).
        const defaultCourseId = first.course_id ?? String(first.id);
        setCreate((p) => ({ ...p, course_id: defaultCourseId }));
      }
    }

    const { data: exData, error: exErr } = await supabase
      .from('exercises')
      .select('id, course_id, prompt, answer_type, points_max, difficulty, requires_ai, requires_photo, image_url, created_at')
      .order('created_at', { ascending: false });

    if (exErr) {
      setMsg(exErr.message);
      setExercises([]);
      setAnswerKeysByExerciseId({});
      setLoading(false);
      return;
    }

    const ids = (exData || []).map((x) => x.id);

    let keysMap = {};
    if (ids.length > 0) {
      const { data: keyRows, error: keyErr } = await supabase
        .from('exercise_answer_keys')
        .select('exercise_id, answer_key')
        .in('exercise_id', ids);

      if (keyErr) {
        setMsg(`Load answer keys failed: ${keyErr.message}`);
      } else {
        keysMap = Object.fromEntries((keyRows || []).map((k) => [k.exercise_id, k.answer_key]));
      }
    }

    setExercises(exData || []);
    setAnswerKeysByExerciseId(keysMap);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return exercises;
    return exercises.filter((e) => {
      const hay = `${e.prompt || ''} ${e.course_id || ''} ${e.id}`.toLowerCase();
      return hay.includes(term);
    });
  }, [exercises, q]);

  async function createExercise() {
    setMsg('');

    if (!create.course_id) {
      setMsg('Wybierz course_id.');
      return;
    }

    const parsed = safeJsonParse(create.answer_key_json);
    if (!parsed.ok) {
      setMsg(`answer_key JSON error: ${parsed.error}`);
      return;
    }

    // 1) create exercise (required fields included)
    const { data: inserted, error: insErr } = await supabase
      .from('exercises')
      .insert({
        course_id: String(create.course_id),
        prompt: create.prompt,
        answer_type: create.answer_type,
        points_max: Number(create.points_max),
        difficulty: Number(create.difficulty),
        requires_ai: Boolean(create.requires_ai),
        requires_photo: Boolean(create.requires_photo),
        image_url: create.image_url || null,
      })
      .select('id')
      .single();

    if (insErr) {
      setMsg(insErr.message);
      return;
    }

    // 2) create answer key
    const { error: keyErr } = await supabase.from('exercise_answer_keys').insert({
      exercise_id: inserted.id,
      answer_key: parsed.value,
    });

    if (keyErr) {
      setMsg(`Exercise created, but answer key insert failed: ${keyErr.message}`);
      await load();
      return;
    }

    setCreate((p) => ({
      ...p,
      prompt: '',
      image_url: '',
      answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
    }));

    await load();
  }

  async function updateExercise(id, patch) {
    setMsg('');
    const { error } = await supabase.from('exercises').update(patch).eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  async function upsertAnswerKey(exerciseId, answerKeyObj) {
    setMsg('');

    const { error } = await supabase.from('exercise_answer_keys').upsert(
      { exercise_id: exerciseId, answer_key: answerKeyObj },
      { onConflict: 'exercise_id' }
    );

    if (error) {
      setMsg(error.message);
      return;
    }

    await load();
  }

  async function deleteExercise(id) {
    setMsg('');
    const ok = window.confirm('Usunąć exercise? Uwaga: island_items mogą się zepsuć.');
    if (!ok) return;

    const { error } = await supabase.from('exercises').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-6xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/admin" className="text-sm font-semibold text-gray-700 underline">
                ← Admin
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Zadania</h1>
              <p className="mt-1 text-sm text-gray-600">
                Wymagane: <code>course_id</code>, <code>difficulty</code>, <code>requires_ai</code>, <code>requires_photo</code>.
              </p>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Dodaj zadanie</div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label>
                  <div className="text-xs font-semibold text-gray-600">Course</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.course_id}
                    onChange={(e) => setCreate((p) => ({ ...p, course_id: e.target.value }))}
                  >
                    <option value="">Wybierz course…</option>
                    {courses.map((c) => {
                      const val = c.course_id ?? String(c.id);
                      return (
                        <option key={val} value={val}>
                          {getCourseLabel(c)}
                        </option>
                      );
                    })}
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">difficulty</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.difficulty}
                    onChange={(e) => setCreate((p) => ({ ...p, difficulty: e.target.value }))}
                  />
                </label>

                <label className="sm:col-span-2">
                  <div className="text-xs font-semibold text-gray-600">Prompt</div>
                  <textarea
                    className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.prompt}
                    onChange={(e) => setCreate((p) => ({ ...p, prompt: e.target.value }))}
                  />
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">answer_type</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.answer_type}
                    onChange={(e) => setCreate((p) => ({ ...p, answer_type: e.target.value }))}
                  >
                    <option value="abcd">abcd</option>
                    <option value="numeric">numeric</option>
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">points_max</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.points_max}
                    onChange={(e) => setCreate((p) => ({ ...p, points_max: e.target.value }))}
                  />
                </label>

                <label className="sm:col-span-2">
                  <div className="text-xs font-semibold text-gray-600">image_url (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    placeholder="https://..."
                    value={create.image_url}
                    onChange={(e) => setCreate((p) => ({ ...p, image_url: e.target.value }))}
                  />
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">requires_ai</div>
                  <div className="mt-2 flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={Boolean(create.requires_ai)}
                      onChange={(e) => setCreate((p) => ({ ...p, requires_ai: e.target.checked }))}
                    />
                    <span className="text-sm text-gray-700">true/false</span>
                  </div>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">requires_photo</div>
                  <div className="mt-2 flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={Boolean(create.requires_photo)}
                      onChange={(e) => setCreate((p) => ({ ...p, requires_photo: e.target.checked }))}
                    />
                    <span className="text-sm text-gray-700">true/false</span>
                  </div>
                </label>
              </div>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">answer_key (JSON)</div>
                <textarea
                  className="mt-1 min-h-[160px] w-full rounded-xl border border-gray-300 px-3 py-2 font-mono text-xs"
                  value={create.answer_key_json}
                  onChange={(e) => setCreate((p) => ({ ...p, answer_key_json: e.target.value }))}
                />
              </label>

              <button
                type="button"
                className="mt-3 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                onClick={createExercise}
              >
                Dodaj
              </button>
            </div>

            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="font-semibold text-gray-900">Lista</div>
                <input
                  className="w-full max-w-xs rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  placeholder="Szukaj…"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                />
              </div>

              {loading ? (
                <div className="mt-4 text-sm text-gray-700">Ładowanie…</div>
              ) : (
                <div className="mt-4 space-y-3">
                  {filtered.map((e) => {
                    const keyObj = answerKeysByExerciseId[e.id] || {};
                    return (
                      <div key={e.id} className="rounded-xl border border-gray-200 p-3">
                        <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                          <div className="text-sm text-gray-900">
                            <b>{e.answer_type}</b> • {e.points_max} pkt • diff {e.difficulty} •{' '}
                            <code className="text-xs">{e.id}</code>
                          </div>
                          <button
                            type="button"
                            className="rounded-lg border border-red-700 bg-red-700 px-3 py-1 text-sm font-semibold text-white"
                            onClick={() => deleteExercise(e.id)}
                          >
                            Usuń
                          </button>
                        </div>

                        <div className="mt-2 grid gap-3 sm:grid-cols-2">
                          <label>
                            <div className="text-xs font-semibold text-gray-600">course_id</div>
                            <input
                              className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                              defaultValue={e.course_id}
                              onBlur={(ev) => updateExercise(e.id, { course_id: String(ev.target.value) })}
                            />
                          </label>

                          <label>
                            <div className="text-xs font-semibold text-gray-600">difficulty</div>
                            <input
                              type="number"
                              className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                              defaultValue={e.difficulty}
                              onBlur={(ev) => updateExercise(e.id, { difficulty: Number(ev.target.value) })}
                            />
                          </label>
                        </div>

                        <label className="mt-2 block">
                          <div className="text-xs font-semibold text-gray-600">Prompt</div>
                          <textarea
                            className="mt-1 min-h-[100px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                            defaultValue={e.prompt || ''}
                            onBlur={(ev) => updateExercise(e.id, { prompt: ev.target.value })}
                          />
                        </label>

                        <div className="mt-2 grid gap-3 sm:grid-cols-3">
                          <label>
                            <div className="text-xs font-semibold text-gray-600">answer_type</div>
                            <select
                              className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                              defaultValue={e.answer_type}
                              onChange={(ev) => updateExercise(e.id, { answer_type: ev.target.value })}
                            >
                              <option value="abcd">abcd</option>
                              <option value="numeric">numeric</option>
                            </select>
                          </label>

                          <label>
                            <div className="text-xs font-semibold text-gray-600">points_max</div>
                            <input
                              type="number"
                              className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                              defaultValue={e.points_max}
                              onBlur={(ev) => updateExercise(e.id, { points_max: Number(ev.target.value) })}
                            />
                          </label>

                          <label className="sm:col-span-3">
                            <div className="text-xs font-semibold text-gray-600">image_url</div>
                            <input
                              className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                              defaultValue={e.image_url || ''}
                              onBlur={(ev) => updateExercise(e.id, { image_url: ev.target.value || null })}
                            />
                          </label>

                          <label>
                            <div className="text-xs font-semibold text-gray-600">requires_ai</div>
                            <div className="mt-2 flex items-center gap-2">
                              <input
                                type="checkbox"
                                defaultChecked={Boolean(e.requires_ai)}
                                onChange={(ev) => updateExercise(e.id, { requires_ai: ev.target.checked })}
                              />
                              <span className="text-sm text-gray-700">true/false</span>
                            </div>
                          </label>

                          <label>
                            <div className="text-xs font-semibold text-gray-600">requires_photo</div>
                            <div className="mt-2 flex items-center gap-2">
                              <input
                                type="checkbox"
                                defaultChecked={Boolean(e.requires_photo)}
                                onChange={(ev) => updateExercise(e.id, { requires_photo: ev.target.checked })}
                              />
                              <span className="text-sm text-gray-700">true/false</span>
                            </div>
                          </label>
                        </div>

                        <label className="mt-2 block">
                          <div className="text-xs font-semibold text-gray-600">answer_key (JSON)</div>
                          <textarea
                            className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 font-mono text-xs"
                            defaultValue={JSON.stringify(keyObj || {}, null, 2)}
                            onBlur={(ev) => {
                              const parsed = safeJsonParse(ev.target.value);
                              if (!parsed.ok) {
                                setMsg(`exercise ${e.id}: answer_key JSON error: ${parsed.error}`);
                                return;
                              }
                              upsertAnswerKey(e.id, parsed.value);
                            }}
                          />
                        </label>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminGate>
  );
}