import { useEffect, useState } from 'react';
import { useRouter } from 'next/router';
import { supabase } from '../../lib/admin';

export default function AdminGate({ children }) {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [isAdmin, setIsAdmin] = useState(false);

  useEffect(() => {
    (async () => {
      const {
        data: { session },
      } = await supabase.auth.getSession();

      if (!session) {
        router.replace('/login');
        return;
      }

      // Check if user is admin
      // Option A: Check email (simple, for MVP)
      const adminEmails = (process.env.NEXT_PUBLIC_ADMIN_EMAILS || '').split(',');
      if (adminEmails.includes(session.user.email)) {
        setIsAdmin(true);
        setLoading(false);
        return;
      }

      // Option B: Check a users table column (more scalable)
      // Uncomment and adjust if you have a 'users' table with 'is_admin' column: 
      /*
      const { data: user, error } = await supabase
        .from('users')
        .select('is_admin')
        .eq('id', session.user.id)
        .single();

      if (! error && user?. is_admin) {
        setIsAdmin(true);
        setLoading(false);
        return;
      }
      */

      // Not admin → redirect
      router.replace('/dashboard');
    })();
  }, [router]);

  if (loading) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white">
        <div className="text-sm text-gray-700">Sprawdzanie uprawnień...</div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-white">
        <div className="text-sm text-red-700">Brak uprawnień administratora. </div>
      </div>
    );
  }

  return <>{children}</>;
}