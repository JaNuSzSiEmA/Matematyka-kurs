-- 1) Courses / Sections / Exercises

create table if not exists public.courses (
  id text primary key,
  title text not null,
  description text default ''
);

create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  course_id text not null references public.courses(id) on delete cascade,
  title text not null,
  order_index int not null default 0
);

create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  section_id uuid references public.sections(id) on delete set null,
  course_id text not null references public.courses(id) on delete cascade,
  prompt text not null,
  answer_type text not null default 'text', -- 'text' | 'numeric' | 'multiple_choice' etc (future)
  answer_key jsonb, -- future autograding
  requires_photo boolean not null default false,
  difficulty int not null default 1,
  points_max int not null default 100,
  created_at timestamptz not null default now()
);

-- 2) Attempts

create table if not exists public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  course_id text not null references public.courses(id) on delete cascade,
  exercise_id uuid references public.exercises(id) on delete set null,

  answer_text text default '',
  solution_image_path text, -- nullable when photo not required / not provided

  ai_transcript_raw text,
  ai_transcript_user text,

  status text not null default 'draft', -- 'draft' | 'submitted' | 'graded'
  is_correct boolean,
  points_awarded int not null default 0,

  started_at timestamptz not null default now(),
  submitted_at timestamptz,
  created_at timestamptz not null default now()
);

-- 3) Enable RLS
alter table public.courses enable row level security;
alter table public.sections enable row level security;
alter table public.exercises enable row level security;
alter table public.exercise_attempts enable row level security;

-- Courses/sections/exercises are readable by anyone (or only logged in if you prefer).
drop policy if exists "courses_read" on public.courses;
create policy "courses_read" on public.courses for select using (true);

drop policy if exists "sections_read" on public.sections;
create policy "sections_read" on public.sections for select using (true);

drop policy if exists "exercises_read" on public.exercises;
create policy "exercises_read" on public.exercises for select using (true);

-- Attempts: user can CRUD only their own
drop policy if exists "attempts_select_own" on public.exercise_attempts;
create policy "attempts_select_own" on public.exercise_attempts
for select using (auth.uid() = user_id);

drop policy if exists "attempts_insert_own" on public.exercise_attempts;
create policy "attempts_insert_own" on public.exercise_attempts
for insert with check (auth.uid() = user_id);

drop policy if exists "attempts_update_own" on public.exercise_attempts;
create policy "attempts_update_own" on public.exercise_attempts
for update using (auth.uid() = user_id);

-- 4) Seed a sample course, sections, exercises
insert into public.courses (id, title, description)
values ('matematyka_podstawa', 'Matematyka – Podstawa', 'Kurs przygotowujący do matury (poziom podstawowy).')
on conflict (id) do update set title = excluded.title;

-- Create a couple of sections
insert into public.sections (course_id, title, order_index)
select 'matematyka_podstawa', x.title, x.order_index
from (values
  ('Arytmetyka (rozgrzewka)', 1),
  ('Geometria', 2)
) as x(title, order_index)
on conflict do nothing;

-- Insert two exercises: one easy (no photo), one proof-like (photo required)
insert into public.exercises (course_id, section_id, prompt, answer_type, requires_photo, difficulty, points_max)
select
  'matematyka_podstawa',
  s.id,
  e.prompt,
  e.answer_type,
  e.requires_photo,
  e.difficulty,
  e.points_max
from public.sections s
join (values
  ('Arytmetyka (rozgrzewka)', 'Oblicz: 2 + 3 = ?', 'numeric', false, 1, 20),
  ('Geometria', 'Udowodnij, że trójkąt o bokach 3, 4, 5 jest prostokątny. (Wstaw zdjęcie rozwiązania.)', 'text', true, 3, 100)
) as e(section_title, prompt, answer_type, requires_photo, difficulty, points_max)
on s.title = e.section_title
where s.course_id = 'matematyka_podstawa';