-- 1) Soft-delete support for islands (so you don't lose user progress when changing structure)
alter table public.islands
  add column if not exists is_active boolean not null default true;

-- Optional index for faster section queries (especially when you start filtering active islands)
create index if not exists idx_islands_section_active_order
  on public.islands (section_id, is_active, order_index);

-- 2) Ensure at most ONE test island per section (partial unique index)
-- Note: this will fail if you already have sections with more than one test island.
create unique index if not exists uq_one_test_island_per_section
  on public.islands (section_id)
  where (type = 'test');