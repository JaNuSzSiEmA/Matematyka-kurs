import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AdminGate from '../../components/admin/AdminGate';
import { supabase } from '../../lib/admin';

function safeJsonParse(str) {
  try {
    return { ok: true, value: JSON.parse(str) };
  } catch (e) {
    return { ok: false, error: e?.message || 'Invalid JSON' };
  }
}

function getCourseLabel(c) {
  return c?.title || c?.name || c?.slug || c?.id || 'course';
}

export default function AdminExercises() {
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [courses, setCourses] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [answerKeysByExerciseId, setAnswerKeysByExerciseId] = useState({});

  const [create, setCreate] = useState({
    course_id: '',
    prompt: '',
    answer_type: 'abcd',
    points_max: 1,
    difficulty: 1,
    requires_ai: false,
    requires_photo: false,
    image_url: '',
    answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
  });

  const [q, setQ] = useState('');

  async function load() {
    setLoading(true);
    setMsg('');

    // FIX: courses has no created_at -> order by title and select known columns
    const { data: courseRows, error: courseErr } = await supabase
      .from('courses')
      .select('id, title, description')
      .order('title', { ascending: true });

    if (courseErr) {
      setMsg(`Load courses failed: ${courseErr.message}`);
      setCourses([]);
    } else {
      setCourses(courseRows || []);
      if (!create.course_id && (courseRows || []).length > 0) {
        setCreate((p) => ({ ...p, course_id: String(courseRows[0].id) }));
      }
    }

    const { data: exData, error: exErr } = await supabase
      .from('exercises')
      .select('id, course_id, prompt, answer_type, points_max, difficulty, requires_ai, requires_photo, image_url, created_at')
      .order('created_at', { ascending: false });

    if (exErr) {
      setMsg(exErr.message);
      setExercises([]);
      setAnswerKeysByExerciseId({});
      setLoading(false);
      return;
    }

    const ids = (exData || []).map((x) => x.id);

    let keysMap = {};
    if (ids.length > 0) {
      const { data: keyRows, error: keyErr } = await supabase
        .from('exercise_answer_keys')
        .select('exercise_id, answer_key')
        .in('exercise_id', ids);

      if (keyErr) setMsg(`Load answer keys failed: ${keyErr.message}`);
      else keysMap = Object.fromEntries((keyRows || []).map((k) => [k.exercise_id, k.answer_key]));
    }

    setExercises(exData || []);
    setAnswerKeysByExerciseId(keysMap);
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return exercises;
    return exercises.filter((e) => {
      const hay = `${e.prompt || ''} ${e.course_id || ''} ${e.id}`.toLowerCase();
      return hay.includes(term);
    });
  }, [exercises, q]);

  async function createExercise() {
    setMsg('');

    if (!create.course_id) {
      setMsg('Wybierz course_id.');
      return;
    }

    const parsed = safeJsonParse(create.answer_key_json);
    if (!parsed.ok) {
      setMsg(`answer_key JSON error: ${parsed.error}`);
      return;
    }

    const { data: inserted, error: insErr } = await supabase
      .from('exercises')
      .insert({
        course_id: String(create.course_id),
        prompt: create.prompt,
        answer_type: create.answer_type,
        points_max: Number(create.points_max),
        difficulty: Number(create.difficulty),
        requires_ai: Boolean(create.requires_ai),
        requires_photo: Boolean(create.requires_photo),
        image_url: create.image_url || null,
      })
      .select('id')
      .single();

    if (insErr) {
      setMsg(insErr.message);
      return;
    }

    const { error: keyErr } = await supabase.from('exercise_answer_keys').insert({
      exercise_id: inserted.id,
      answer_key: parsed.value,
    });

    if (keyErr) {
      setMsg(`Exercise created, but answer key insert failed: ${keyErr.message}`);
      await load();
      return;
    }

    setCreate((p) => ({
      ...p,
      prompt: '',
      image_url: '',
      answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
    }));

    await load();
  }

  async function updateExercise(id, patch) {
    setMsg('');
    const { error } = await supabase.from('exercises').update(patch).eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  async function upsertAnswerKey(exerciseId, answerKeyObj) {
    setMsg('');
    const { error } = await supabase.from('exercise_answer_keys').upsert(
      { exercise_id: exerciseId, answer_key: answerKeyObj },
      { onConflict: 'exercise_id' }
    );
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  async function deleteExercise(id) {
    setMsg('');
    const ok = window.confirm('Usunąć exercise? Uwaga: island_items mogą się zepsuć.');
    if (!ok) return;

    const { error } = await supabase.from('exercises').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-6xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/admin" className="text-sm font-semibold text-gray-700 underline">
                ← Admin
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Zadania</h1>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Dodaj zadanie</div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label>
                  <div className="text-xs font-semibold text-gray-600">Course</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.course_id}
                    onChange={(e) => setCreate((p) => ({ ...p, course_id: e.target.value }))}
                  >
                    <option value="">Wybierz course…</option>
                    {courses.map((c) => (
                      <option key={c.id} value={String(c.id)}>
                        {getCourseLabel(c)}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">difficulty</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.difficulty}
                    onChange={(e) => setCreate((p) => ({ ...p, difficulty: e.target.value }))}
                  />
                </label>
              </div>

              {/* rest of your component unchanged (prompt/type/points/image/flags/answer_key, list, etc.) */}
              {/* For brevity I didn’t re-paste the remaining JSX; keep it from your current file. */}
              {/* IMPORTANT: only the courses loading + dropdown value mapping needed fixing. */}
              <div className="mt-3 text-sm text-gray-600">
                Zaktualizowałem ładowanie kursów (order by <code>title</code>). Zachowaj resztę pliku jak masz.
              </div>

              <button
                type="button"
                className="mt-3 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                onClick={createExercise}
              >
                Dodaj
              </button>
            </div>

            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Lista</div>
              <div className="mt-2 text-sm text-gray-600">
                (Tu też zachowaj resztę listy z Twojego aktualnego pliku.)
              </div>
            </div>
          </div>
        </div>
      </div>
    </AdminGate>
  );
}