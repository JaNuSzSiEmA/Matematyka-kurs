import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AdminGate from '../../components/admin/AdminGate';
import { supabase } from '../../lib/admin';

function safeJsonParse(str) {
  try {
    return { ok: true, value: JSON.parse(str) };
  } catch (e) {
    return { ok: false, error: e?.message || 'Invalid JSON' };
  }
}

export default function AdminExercises() {
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [exercises, setExercises] = useState([]);

  // Create form
  const [create, setCreate] = useState({
    prompt: '',
    answer_type: 'abcd',
    points_max: 1,
    image_url: '',
    answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
  });

  // Filter
  const [q, setQ] = useState('');

  async function load() {
    setLoading(true);
    setMsg('');

    const { data, error } = await supabase
      .from('exercises')
      .select('id, prompt, answer_type, points_max, image_url, answer_key, created_at')
      .order('created_at', { ascending: false });

    if (error) {
      setMsg(error.message);
      setExercises([]);
      setLoading(false);
      return;
    }
    setExercises(data || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  const filtered = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return exercises;
    return exercises.filter((e) => (e.prompt || '').toLowerCase().includes(term) || String(e.id).includes(term));
  }, [exercises, q]);

  async function createExercise() {
    setMsg('');

    const parsed = safeJsonParse(create.answer_key_json);
    if (!parsed.ok) {
      setMsg(`answer_key JSON error: ${parsed.error}`);
      return;
    }

    const payload = {
      prompt: create.prompt,
      answer_type: create.answer_type,
      points_max: Number(create.points_max),
      image_url: create.image_url || null,
      answer_key: parsed.value,
    };

    const { error } = await supabase.from('exercises').insert(payload);
    if (error) {
      setMsg(error.message);
      return;
    }

    setCreate({
      prompt: '',
      answer_type: 'abcd',
      points_max: 1,
      image_url: '',
      answer_key_json: JSON.stringify({ correct: 'A' }, null, 2),
    });

    await load();
  }

  async function updateExercise(id, patch) {
    setMsg('');
    const { error } = await supabase.from('exercises').update(patch).eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  async function deleteExercise(id) {
    setMsg('');
    const ok = window.confirm('Usunąć exercise? Uwaga: island_items mogą się zepsuć.');
    if (!ok) return;

    const { error } = await supabase.from('exercises').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-6xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <Link href="/admin" className="text-sm font-semibold text-gray-700 underline">
                ← Admin
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Zadania</h1>
              <p className="mt-1 text-sm text-gray-600">
                Twórz i edytuj zadania. <code>answer_key</code> wpisuj jako JSON.
              </p>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Dodaj zadanie</div>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">Prompt</div>
                <textarea
                  className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.prompt}
                  onChange={(e) => setCreate((p) => ({ ...p, prompt: e.target.value }))}
                />
              </label>

              <div className="mt-3 grid gap-3 sm:grid-cols-3">
                <label>
                  <div className="text-xs font-semibold text-gray-600">answer_type</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.answer_type}
                    onChange={(e) => setCreate((p) => ({ ...p, answer_type: e.target.value }))}
                  >
                    <option value="abcd">abcd</option>
                    <option value="numeric">numeric</option>
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">points_max</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.points_max}
                    onChange={(e) => setCreate((p) => ({ ...p, points_max: e.target.value }))}
                  />
                </label>

                <label className="sm:col-span-3">
                  <div className="text-xs font-semibold text-gray-600">image_url (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    placeholder="https://..."
                    value={create.image_url}
                    onChange={(e) => setCreate((p) => ({ ...p, image_url: e.target.value }))}
                  />
                </label>
              </div>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">answer_key (JSON)</div>
                <textarea
                  className="mt-1 min-h-[160px] w-full rounded-xl border border-gray-300 px-3 py-2 font-mono text-xs"
                  value={create.answer_key_json}
                  onChange={(e) => setCreate((p) => ({ ...p, answer_key_json: e.target.value }))}
                />
                <div className="mt-1 text-xs text-gray-500">
                  abcd example: <code>{`{ "correct": "A" }`}</code> • numeric example: <code>{`{ "value": 42 }`}</code>
                </div>
              </label>

              <button
                type="button"
                className="mt-3 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                onClick={createExercise}
              >
                Dodaj
              </button>
            </div>

            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="flex items-center justify-between gap-3">
                <div className="font-semibold text-gray-900">Lista</div>
                <input
                  className="w-full max-w-xs rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  placeholder="Szukaj w prompt…"
                  value={q}
                  onChange={(e) => setQ(e.target.value)}
                />
              </div>

              {loading ? (
                <div className="mt-4 text-sm text-gray-700">Ładowanie…</div>
              ) : (
                <div className="mt-4 space-y-3">
                  {filtered.map((e) => (
                    <div key={e.id} className="rounded-xl border border-gray-200 p-3">
                      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                        <div className="text-sm text-gray-900">
                          <b>{e.answer_type}</b> • {e.points_max} pkt • <code className="text-xs">{e.id}</code>
                        </div>
                        <button
                          type="button"
                          className="rounded-lg border border-red-700 bg-red-700 px-3 py-1 text-sm font-semibold text-white"
                          onClick={() => deleteExercise(e.id)}
                        >
                          Usuń
                        </button>
                      </div>

                      <label className="mt-2 block">
                        <div className="text-xs font-semibold text-gray-600">Prompt</div>
                        <textarea
                          className="mt-1 min-h-[100px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                          defaultValue={e.prompt || ''}
                          onBlur={(ev) => updateExercise(e.id, { prompt: ev.target.value })}
                        />
                        <div className="mt-1 text-xs text-gray-500">Zapis na blur.</div>
                      </label>

                      <div className="mt-2 grid gap-3 sm:grid-cols-3">
                        <label>
                          <div className="text-xs font-semibold text-gray-600">answer_type</div>
                          <select
                            className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                            defaultValue={e.answer_type}
                            onChange={(ev) => updateExercise(e.id, { answer_type: ev.target.value })}
                          >
                            <option value="abcd">abcd</option>
                            <option value="numeric">numeric</option>
                          </select>
                        </label>

                        <label>
                          <div className="text-xs font-semibold text-gray-600">points_max</div>
                          <input
                            type="number"
                            className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                            defaultValue={e.points_max}
                            onBlur={(ev) => updateExercise(e.id, { points_max: Number(ev.target.value) })}
                          />
                        </label>

                        <label className="sm:col-span-3">
                          <div className="text-xs font-semibold text-gray-600">image_url</div>
                          <input
                            className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                            defaultValue={e.image_url || ''}
                            onBlur={(ev) => updateExercise(e.id, { image_url: ev.target.value || null })}
                          />
                        </label>
                      </div>

                      <label className="mt-2 block">
                        <div className="text-xs font-semibold text-gray-600">answer_key (JSON)</div>
                        <textarea
                          className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 font-mono text-xs"
                          defaultValue={JSON.stringify(e.answer_key || {}, null, 2)}
                          onBlur={(ev) => {
                            const parsed = safeJsonParse(ev.target.value);
                            if (!parsed.ok) {
                              setMsg(`exercise ${e.id}: answer_key JSON error: ${parsed.error}`);
                              return;
                            }
                            updateExercise(e.id, { answer_key: parsed.value });
                          }}
                        />
                        <div className="mt-1 text-xs text-gray-500">Uwaga: błędny JSON pokaże błąd na górze.</div>
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminGate>
  );
}