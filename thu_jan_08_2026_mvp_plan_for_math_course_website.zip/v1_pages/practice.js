import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { supabase } from '../lib/supabaseClient';

export default function PracticePage() {
  const [sessionEmail, setSessionEmail] = useState(null);

  const [loadingExercise, setLoadingExercise] = useState(true);
  const [exercise, setExercise] = useState(null);

  const [answerText, setAnswerText] = useState('');
  const [imageUploading, setImageUploading] = useState(false);
  const [imagePath, setImagePath] = useState(null);

  const [transcribing, setTranscribing] = useState(false);
  const [transcriptRaw, setTranscriptRaw] = useState('');
  const [transcriptUser, setTranscriptUser] = useState('');

  const [submitting, setSubmitting] = useState(false);
  const [msg, setMsg] = useState('');

  const courseId = 'matematyka_podstawa';

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      setSessionEmail(data?.session?.user?.email ?? null);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      setSessionEmail(session?.user?.email ?? null);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  async function loadRandomExercise() {
    setMsg('');
    setLoadingExercise(true);
    setExercise(null);
    setAnswerText('');
    setImagePath(null);
    setTranscriptRaw('');
    setTranscriptUser('');

    // Load a handful then pick random client-side (simple)
    const { data, error } = await supabase
      .from('exercises')
      .select('id, prompt, requires_photo, points_max')
      .eq('course_id', courseId)
      .limit(50);

    if (error) {
      setMsg('Błąd ładowania ćwiczeń: ' + error.message);
      setLoadingExercise(false);
      return;
    }

    if (!data || data.length === 0) {
      setMsg('Brak ćwiczeń w bazie danych.');
      setLoadingExercise(false);
      return;
    }

    const picked = data[Math.floor(Math.random() * data.length)];
    setExercise(picked);
    setLoadingExercise(false);
  }

  useEffect(() => {
    loadRandomExercise();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const photoRequired = useMemo(() => Boolean(exercise?.requires_photo), [exercise]);

  async function uploadSolutionImage(file) {
    setMsg('');
    setImageUploading(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMsg('Musisz być zalogowany, aby wysłać zdjęcie.');
        return;
      }

      const userId = session.user.id;
      const ext = file.name.split('.').pop() || 'jpg';
      const filename = `${Date.now()}-${Math.random().toString(16).slice(2)}.${ext}`;
      const path = `${userId}/${courseId}/${exercise.id}/${filename}`;

      const { error } = await supabase.storage
        .from('solutions')
        .upload(path, file, { upsert: false, contentType: file.type });

      if (error) {
        setMsg('Błąd uploadu: ' + error.message);
        return;
      }

      setImagePath(path);

      // Auto-transcribe after upload
      setTranscribing(true);
      const resp = await fetch('/api/transcribe-solution', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imagePath: path, courseId }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        setMsg(json.error || `Błąd transkrypcji (HTTP ${resp.status})`);
        return;
      }

      setTranscriptRaw(json.transcript_raw || '');
      setTranscriptUser(json.transcript_raw || '');
    } finally {
      setTranscribing(false);
      setImageUploading(false);
    }
  }

  async function submitAttempt() {
    setMsg('');
    setSubmitting(true);

    try {
      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        setMsg('Musisz być zalogowany, aby wysłać odpowiedź.');
        return;
      }

      if (!exercise) {
        setMsg('Nie załadowano ćwiczenia.');
        return;
      }

      if (photoRequired && !imagePath) {
        setMsg('To zadanie wymaga zdjęcia rozwiązania.');
        return;
      }

      const resp = await fetch('/api/submit-attempt', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${session.access_token}` },
        body: JSON.stringify({
          courseId,
          exerciseId: exercise.id,
          answerText,
          imagePath,
          transcriptRaw,
          transcriptUser,
        }),
      });

      const json = await resp.json().catch(() => ({}));
      if (!resp.ok) {
        setMsg(json.error || `Błąd wysyłki (HTTP ${resp.status})`);
        return;
      }

      setMsg(`Zapisano próbę. Punkty: ${json.points_awarded ?? 0}. Poprawne: ${json.is_correct ? 'TAK' : 'NIE'}.`);
    } finally {
      setSubmitting(false);
    }
  }

  if (!sessionEmail) {
    return (
      <div style={wrap()}>
        <div style={card()}>
          <h1>Trening</h1>
          <p>Musisz się zalogować.</p>
          <Link href="/login">Przejdź do logowania</Link>
        </div>
      </div>
    );
  }

  return (
    <div style={wrap()}>
      <div style={card()}>
        <div style={{ display: 'flex', justifyContent: 'space-between', gap: 12, flexWrap: 'wrap' }}>
          <h1 style={{ margin: 0 }}>Trening</h1>
          <div style={{ fontSize: 13, color: '#374151' }}>Zalogowany jako: {sessionEmail}</div>
        </div>

        <div style={{ marginTop: 12 }}>
          <button onClick={loadRandomExercise} disabled={loadingExercise} style={btn()}>
            Losuj nowe zadanie
          </button>
        </div>

        <hr style={hr()} />

        {loadingExercise ? (
          <div>Ładowanie zadania…</div>
        ) : exercise ? (
          <>
            <div style={{ padding: 12, background: '#f9fafb', border: '1px solid #e5e7eb', borderRadius: 12 }}>
              <div style={{ fontSize: 12, color: '#6b7280' }}>
                Punkty max: {exercise.points_max} • Zdjęcie wymagane: {exercise.requires_photo ? 'TAK' : 'NIE'}
              </div>
              <div style={{ marginTop: 8, fontSize: 16 }}>{exercise.prompt}</div>
            </div>

            <div style={{ marginTop: 14 }}>
              <label style={label()}>
                Odpowiedź (jeśli da się wpisać)
                <input
                  value={answerText}
                  onChange={(e) => setAnswerText(e.target.value)}
                  placeholder="Wpisz odpowiedź…"
                  style={input()}
                />
              </label>
            </div>

            <div style={{ marginTop: 8 }}>
              <label style={label()}>
                Zdjęcie rozwiązania {photoRequired ? '(wymagane)' : '(opcjonalne)'}
                <input
                  type="file"
                  accept="image/*"
                  disabled={imageUploading}
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) uploadSolutionImage(file);
                  }}
                />
              </label>

              {imagePath ? (
                <div style={{ fontSize: 13, color: '#065f46' }}>
                  Wysłano: <code>{imagePath}</code>
                </div>
              ) : null}

              {imageUploading ? <div style={{ marginTop: 6 }}>Wysyłanie zdjęcia…</div> : null}
              {transcribing ? <div style={{ marginTop: 6 }}>AI analizuje zdjęcie (transkrypcja)…</div> : null}
            </div>

            <div style={{ marginTop: 14 }}>
              <h3 style={{ marginBottom: 6 }}>Transkrypcja AI (do sprawdzenia)</h3>
              <p style={{ marginTop: 0, fontSize: 13, color: '#6b7280' }}>
                AI może się pomylić. Popraw tekst, jeśli coś źle odczytało (Twoje poprawki zostaną zapisane).
              </p>

              <textarea
                value={transcriptUser}
                onChange={(e) => setTranscriptUser(e.target.value)}
                placeholder="Tu pojawi się transkrypcja po wysłaniu zdjęcia…"
                style={textarea()}
              />
            </div>

            <button
              onClick={submitAttempt}
              disabled={submitting || (photoRequired && !imagePath)}
              style={btn({ width: '100%', marginTop: 14 })}
            >
              {submitting ? 'Wysyłanie…' : 'Zapisz próbę'}
            </button>
          </>
        ) : (
          <div>Nie udało się załadować zadania.</div>
        )}

        {msg ? <p style={{ marginTop: 12 }}>{msg}</p> : null}
      </div>
    </div>
  );
}

function wrap() {
  return { minHeight: '100vh', display: 'grid', placeItems: 'center', padding: 24, background: '#ffffff' };
}
function card() {
  return { width: '100%', maxWidth: 720, border: '1px solid #e5e7eb', borderRadius: 14, padding: 18 };
}
function input() {
  return { width: '100%', padding: '10px 12px', borderRadius: 10, border: '1px solid #d1d5db', marginTop: 6 };
}
function textarea() {
  return { width: '100%', minHeight: 150, padding: '10px 12px', borderRadius: 10, border: '1px solid #d1d5db' };
}
function label() {
  return { display: 'block', fontSize: 14, color: '#111827' };
}
function btn(extra = {}) {
  return { padding: '10px 12px', borderRadius: 10, border: '1px solid #111827', background: '#111827', color: 'white', cursor: 'pointer', ...extra };
}
function hr() {
  return { margin: '16px 0', border: 0, borderTop: '1px solid #e5e7eb' };
}