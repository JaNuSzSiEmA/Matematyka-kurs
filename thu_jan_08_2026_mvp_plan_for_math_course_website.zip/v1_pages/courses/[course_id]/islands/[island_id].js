import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useRouter } from 'next/router';
import Link from 'next/link';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

function toEmbedUrl(youtubeUrl) {
  if (!youtubeUrl) return null;
  // Accept both youtu.be and youtube.com/watch?v=
  try {
    const url = new URL(youtubeUrl);
    if (url.hostname.includes('youtu.be')) {
      return `https://www.youtube.com/embed/${url.pathname.replace('/', '')}`;
    }
    const vid = url.searchParams.get('v');
    if (vid) return `https://www.youtube.com/embed/${vid}`;
    // already embed?
    if (youtubeUrl.includes('/embed/')) return youtubeUrl;
    return youtubeUrl;
  } catch {
    return youtubeUrl;
  }
}

export default function IslandPage() {
  const router = useRouter();
  const { course_id, island_id } = router.query;

  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [island, setIsland] = useState(null);
  const [items, setItems] = useState([]);

  useEffect(() => {
    if (!course_id || !island_id) return;

    (async () => {
      setLoading(true);
      setMsg('');

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.replace('/login');
        return;
      }

      const { data: isl, error: islErr } = await supabase
        .from('islands')
        .select('id, title, type, order_index, section_id')
        .eq('id', island_id)
        .single();

      if (islErr || !isl) {
        setMsg('Nie znaleziono wyspy.');
        setLoading(false);
        return;
      }
      setIsland(isl);

      const { data: its, error: itsErr } = await supabase
        .from('island_items')
        .select('id, item_type, order_index, title, youtube_url, exercise_id')
        .eq('island_id', island_id)
        .order('order_index', { ascending: true });

      if (itsErr) {
        setMsg('Błąd pobierania elementów wyspy: ' + itsErr.message);
        setItems([]);
      } else {
        setItems(its || []);
      }

      setLoading(false);
    })();
  }, [course_id, island_id, router]);

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-3xl p-6 text-sm text-gray-700">Ładowanie…</div>
      </div>
    );
  }

  const isTest = island?.type === 'test';

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-3xl p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link href="/dashboard" className="text-sm font-semibold text-gray-700 underline">
              ← Panel
            </Link>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">
              {isTest ? 'Test' : 'Wyspa'}: {island?.title}
            </h1>
            <p className="mt-1 text-sm text-gray-600">
              {isTest
                ? 'To jest wyspa testowa. Docelowo będzie tu 6 zadań i wynik w %.'
                : 'To jest wyspa treningowa (wideo + ćwiczenia).'}
            </p>
          </div>

          <span className={`h-fit rounded-full px-3 py-1 text-xs font-semibold ${isTest ? 'bg-indigo-100 text-indigo-800' : 'bg-gray-100 text-gray-800'}`}>
            {isTest ? 'TEST' : 'NORMAL'}
          </span>
        </div>

        {msg ? <div className="mt-4 text-sm text-red-700">{msg}</div> : null}

        <div className="mt-6 space-y-4">
          {items.length === 0 ? (
            <div className="rounded-2xl border border-gray-200 p-4 text-sm text-gray-700">
              Brak elementów w tej wyspie (na razie). Dodamy je w seedzie treści.
            </div>
          ) : (
            items.map((it) => (
              <div key={it.id} className="rounded-2xl border border-gray-200 p-4">
                <div className="text-xs font-semibold text-gray-500">
                  {it.item_type === 'video' ? 'WIDEO' : 'ĆWICZENIE'} • #{it.order_index}
                </div>
                <div className="mt-1 text-base font-semibold text-gray-900">
                  {it.title || (it.item_type === 'video' ? 'Lekcja wideo' : 'Ćwiczenie')}
                </div>

                {it.item_type === 'video' ? (
                  <div className="mt-3 aspect-video w-full overflow-hidden rounded-xl bg-black">
                    <iframe
                      className="h-full w-full"
                      src={toEmbedUrl(it.youtube_url)}
                      title={it.title || 'YouTube video'}
                      allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                      allowFullScreen
                    />
                  </div>
                ) : (
                  <div className="mt-3 text-sm text-gray-700">
                    (MVP) Tu będzie UI ćwiczenia. exercise_id: <code>{it.exercise_id}</code>
                  </div>
                )}
              </div>
            ))
          )}
        </div>

        <div className="mt-8 rounded-2xl border border-gray-200 p-4 text-sm text-gray-700">
          Następny krok: dodać seed przykładowych island_items + exercises (w tym test: dokładnie 6 zadań).
        </div>
      </div>
    </div>
  );
}