import { getBearerToken, getSupabaseServerClient } from './_supabase';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Missing bearer token' });

  const supabase = getSupabaseServerClient();

  const { data: userData, error: userErr } = await supabase.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: 'Invalid token' });

  const userId = userData.user.id;

  const { island_id } = req.body || {};
  if (!island_id) return res.status(400).json({ error: 'Missing island_id' });

  // Load island + section
  const { data: island, error: islErr } = await supabase
    .from('islands')
    .select('id, type, section_id')
    .eq('id', island_id)
    .single();

  if (islErr || !island) return res.status(404).json({ error: 'Island not found' });
  if (island.type !== 'test') return res.status(400).json({ error: 'Not a test island' });

  // Load the 6 test exercises from island_items (in order)
  const { data: items, error: itemsErr } = await supabase
    .from('island_items')
    .select('order_index, exercise_id')
    .eq('island_id', island_id)
    .eq('item_type', 'exercise')
    .order('order_index', { ascending: true });

  if (itemsErr) return res.status(500).json({ error: itemsErr.message });

  const exerciseIds = (items || []).map((x) => x.exercise_id).filter(Boolean);
  if (exerciseIds.length !== 6) {
    return res.status(400).json({ error: `Expected exactly 6 test exercises, got ${exerciseIds.length}` });
  }

  // For each exercise, get latest attempt correctness by this user
  // MVP approach: fetch all attempts for these exercises and pick newest per exercise.
  const { data: attempts, error: attErr } = await supabase
    .from('exercise_attempts')
    .select('exercise_id, is_correct, created_at')
    .eq('user_id', userId)
    .in('exercise_id', exerciseIds)
    .order('created_at', { ascending: false });

  if (attErr) return res.status(500).json({ error: attErr.message });

  const latestByExercise = new Map();
  for (const a of attempts || []) {
    if (!latestByExercise.has(a.exercise_id)) latestByExercise.set(a.exercise_id, a);
  }

  let correctCount = 0;
  for (const exId of exerciseIds) {
    const a = latestByExercise.get(exId);
    if (a?.is_correct === true) correctCount += 1;
  }

  const scorePercent = Math.round((correctCount / 6) * 100);
  const passed = scorePercent >= 60;

  // Insert attempt row
  const { error: insErr } = await supabase.from('section_test_attempts').insert({
    user_id: userId,
    section_id: island.section_id,
    score_percent: scorePercent,
    passed,
  });
  if (insErr) return res.status(500).json({ error: insErr.message });

  // Upsert section_progress with best score
  const { data: existing, error: exProgErr } = await supabase
    .from('section_progress')
    .select('id, best_test_score_percent')
    .eq('user_id', userId)
    .eq('section_id', island.section_id)
    .maybeSingle();

  if (exProgErr) return res.status(500).json({ error: exProgErr.message });

  const prevBest = existing?.best_test_score_percent || 0;
  const best = Math.max(prevBest, scorePercent);
  const completed = best >= 60;

  // For now: points_total fields stay 0; we'll add recompute_best + catch-up next.
  if (existing?.id) {
    const { error: upErr } = await supabase
      .from('section_progress')
      .update({
        best_test_score_percent: best,
        completed,
        updated_at: new Date().toISOString(),
      })
      .eq('id', existing.id);

    if (upErr) return res.status(500).json({ error: upErr.message });
  } else {
    const { error: upErr } = await supabase.from('section_progress').insert({
      user_id: userId,
      section_id: island.section_id,
      best_test_score_percent: best,
      completed,
      points_done: 0,
      points_catchup: 0,
      points_total: 0,
    });

    if (upErr) return res.status(500).json({ error: upErr.message });
  }

 