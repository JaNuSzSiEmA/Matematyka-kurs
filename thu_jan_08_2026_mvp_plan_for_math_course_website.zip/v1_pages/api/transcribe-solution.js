export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');

  const { imagePath } = req.body || {};
  if (!imagePath) return res.status(400).json({ error: 'Brak imagePath' });

  // STUB: later replace with OCR/Vision model output
  const transcript = [
    'TRANSKRYPCJA (STUB):',
    `Plik: ${imagePath}`,
    '',
    'Przykładowe odczytane kroki:',
    '1) Dane: a = 3, b = 4, c = 5',
    '2) Sprawdzam: 3^2 + 4^2 = 9 + 16 = 25 = 5^2',
    '3) Wniosek: trójkąt jest prostokątny',
  ].join('\n');

  return res.status(200).json({ transcript_raw: transcript });
}