import { createClient } from '@supabase/supabase-js';

export default async function handler(req, res) {
  try {
    if (req.method !== 'POST') return res.status(405).end('Method Not Allowed');

    const authHeader = req.headers.authorization || '';
    const tokenMatch = authHeader.match(/^Bearer (.+)$/);
    if (!tokenMatch) return res.status(401).json({ error: 'Brak nagłówka Authorization' });

    const accessToken = tokenMatch[1];

    if (!process.env.SUPABASE_URL || !process.env.SUPABASE_SERVICE_ROLE_KEY) {
      return res.status(500).json({ error: 'Brak konfiguracji SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY' });
    }

    const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_ROLE_KEY);

    const { data: userData, error: userErr } = await supabase.auth.getUser(accessToken);
    if (userErr || !userData?.user) return res.status(401).json({ error: 'Niepoprawny token' });

    const userId = userData.user.id;

    const { courseId, exerciseId, answerText, imagePath, transcriptRaw, transcriptUser } = req.body || {};
    if (!courseId || !exerciseId) return res.status(400).json({ error: 'Brak courseId lub exerciseId' });

    // Load exercise rules (photo required, points_max, etc.)
    const { data: ex, error: exErr } = await supabase
      .from('exercises')
      .select('id, requires_photo, points_max, prompt')
      .eq('id', exerciseId)
      .single();

    if (exErr || !ex) return res.status(400).json({ error: 'Nie znaleziono ćwiczenia' });

    if (ex.requires_photo && !imagePath) {
      return res.status(400).json({ error: 'To zadanie wymaga zdjęcia rozwiązania.' });
    }

    // Very simple scoring for now:
    // - If answer is "5" for the easy 2+3 exercise -> correct
    // - Otherwise we can't autograde yet -> mark unknown/false and give 0 (AI grading later)
    let isCorrect = null;
    let points = 0;

    const normalized = String(answerText || '').trim();
    if (ex.prompt.includes('2 + 3') && normalized === '5') {
      isCorrect = true;
      points = Math.min(20, ex.points_max);
    } else {
      // Not graded yet (future AI/answer_key)
      isCorrect = false;
      points = 0;
    }

    const { data: attempt, error: insErr } = await supabase
      .from('exercise_attempts')
      .insert({
        user_id: userId,
        course_id: courseId,
        exercise_id: exerciseId,
        answer_text: answerText || '',
        solution_image_path: imagePath || null,
        ai_transcript_raw: transcriptRaw || null,
        ai_transcript_user: transcriptUser || null,
        status: 'graded',
        is_correct: isCorrect,
        points_awarded: points,
        submitted_at: new Date().toISOString(),
      })
      .select('*')
      .single();

    if (insErr) return res.status(500).json({ error: 'Błąd zapisu próby', details: insErr.message });

    return res.status(200).json({
      ok: true,
      attempt_id: attempt.id,
      is_correct: attempt.is_correct,
      points_awarded: attempt.points_awarded,
    });
  } catch (e) {
    console.error('submit-attempt crashed:', e);
    return res.status(500).json({ error: 'submit-attempt crashed', details: e?.message || String(e) });
  }
}