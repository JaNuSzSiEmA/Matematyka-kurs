import { getBearerToken, getSupabaseServerClient } from './_supabase';

function normalizeNumeric(v) {
  // Accept "25", "25.0", "25,0" etc.
  if (typeof v !== 'string' && typeof v !== 'number') return null;
  const s = String(v).trim().replace(',', '.');
  if (!s) return null;
  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'Method not allowed' });

  const token = getBearerToken(req);
  if (!token) return res.status(401).json({ error: 'Missing bearer token' });

  const supabase = getSupabaseServerClient();

  const { data: userData, error: userErr } = await supabase.auth.getUser(token);
  if (userErr || !userData?.user) return res.status(401).json({ error: 'Invalid token' });

  const userId = userData.user.id;

  const { exercise_id, island_id, answer, time_spent_sec } = req.body || {};
  if (!exercise_id || !island_id) return res.status(400).json({ error: 'Missing exercise_id or island_id' });

  const { data: ex, error: exErr } = await supabase
    .from('exercises')
    .select('id, answer_type, answer_key, points_max')
    .eq('id', exercise_id)
    .single();

  if (exErr || !ex) return res.status(404).json({ error: 'Exercise not found' });

  let isCorrect = null;

  if (ex.answer_type === 'numeric') {
    const userVal = normalizeNumeric(answer?.value);
    const correctVal = normalizeNumeric(ex.answer_key?.value);
    if (userVal === null || correctVal === null) {
      isCorrect = false;
    } else {
      // exact match for MVP
      isCorrect = userVal === correctVal;
    }
  } else if (ex.answer_type === 'abcd') {
    const userChoice = String(answer?.choice || '').trim().toUpperCase();
    const correct = String(ex.answer_key?.correct || '').trim().toUpperCase();
    isCorrect = Boolean(userChoice) && userChoice === correct;
  } else {
    return res.status(400).json({ error: `Unsupported answer_type for autograde: ${ex.answer_type}` });
  }

  // MVP points: full points for correct, 0 for wrong
  const pointsAwarded = isCorrect ? ex.points_max : 0;

  const { error: insErr } = await supabase.from('exercise_attempts').insert({
    user_id: userId,
    exercise_id: ex.id,
    island_id,
    answer,
    is_correct: isCorrect,
    points_awarded: pointsAwarded,
    time_spent_sec: Math.max(0, Number(time_spent_sec || 0) || 0),
  });

  if (insErr) return res.status(500).json({ error: insErr.message });

  return res.status(200).json({ is_correct: isCorrect, points_awarded: pointsAwarded });
}