-- 1) New table holding correct answers (admin-only)
create table if not exists public.exercise_answer_keys (
  exercise_id uuid primary key references public.exercises(id) on delete cascade,
  answer_key jsonb not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

-- Keep updated_at fresh
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

drop trigger if exists trg_exercise_answer_keys_updated_at on public.exercise_answer_keys;
create trigger trg_exercise_answer_keys_updated_at
before update on public.exercise_answer_keys
for each row execute function public.set_updated_at();

-- 2) Enable RLS + admin-only policies
alter table public.exercise_answer_keys enable row level security;

drop policy if exists "exercise_answer_keys admin select" on public.exercise_answer_keys;
create policy "exercise_answer_keys admin select"
on public.exercise_answer_keys
for select
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "exercise_answer_keys admin write" on public.exercise_answer_keys;
create policy "exercise_answer_keys admin write"
on public.exercise_answer_keys
for all
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));

-- 3) Migrate data from exercises.answer_key into the new table
insert into public.exercise_answer_keys (exercise_id, answer_key)
select id, answer_key
from public.exercises
where answer_key is not null
on conflict (exercise_id) do update
set answer_key = excluded.answer_key;

-- 4) IMPORTANT: remove public read access to answer_key by wiping it (optional but recommended)
-- This keeps column but makes it harmless even if someone selects it.
update public.exercises
set answer_key = null
where answer_key is not null;