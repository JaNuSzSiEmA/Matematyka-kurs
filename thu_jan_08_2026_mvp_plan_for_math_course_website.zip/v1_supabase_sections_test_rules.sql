alter table public.sections
  add column if not exists test_questions_count int not null default 6,
  add column if not exists pass_percent int not null default 60;

-- Optional sanity constraints
alter table public.sections
  add constraint if not exists sections_test_questions_count_check
  check (test_questions_count >= 1 and test_questions_count <= 50);

alter table public.sections
  add constraint if not exists sections_pass_percent_check
  check (pass_percent >= 1 and pass_percent <= 100);