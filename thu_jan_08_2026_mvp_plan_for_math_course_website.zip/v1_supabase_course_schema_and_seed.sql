-- Extensions (gen_random_uuid)
create extension if not exists pgcrypto;

-- COURSES
create table if not exists public.courses (
  id text primary key,
  title text not null,
  description text default ''
);

-- SECTIONS
create table if not exists public.sections (
  id uuid primary key default gen_random_uuid(),
  course_id text not null references public.courses(id) on delete cascade,
  slug text not null,
  title text not null,
  order_index int not null default 0,
  is_free boolean not null default false,
  unique (course_id, slug)
);

-- ISLANDS (path nodes)
create table if not exists public.islands (
  id uuid primary key default gen_random_uuid(),
  section_id uuid not null references public.sections(id) on delete cascade,
  title text not null,
  type text not null default 'normal', -- 'normal' | 'test'
  order_index int not null default 0,
  max_points int not null default 0, -- used for catch-up scoring; for test island can be 0 or a value if you want
  created_at timestamptz not null default now()
);

-- ISLAND ITEMS (videos/exercises inside an island)
create table if not exists public.island_items (
  id uuid primary key default gen_random_uuid(),
  island_id uuid not null references public.islands(id) on delete cascade,
  item_type text not null, -- 'video' | 'exercise'
  order_index int not null default 0,
  title text default '',
  youtube_url text,        -- for item_type='video'
  exercise_id uuid,        -- for item_type='exercise'
  created_at timestamptz not null default now()
);

-- EXERCISES
create table if not exists public.exercises (
  id uuid primary key default gen_random_uuid(),
  course_id text not null references public.courses(id) on delete cascade,
  section_id uuid references public.sections(id) on delete set null,
  prompt text not null,
  answer_type text not null default 'single', -- 'single' | 'abcd' | 'numeric' | 'open' (extend later)
  answer_key jsonb, -- for abcd/numeric autograde
  difficulty int not null default 1,
  points_max int not null default 100,
  requires_ai boolean not null default false,
  requires_photo boolean not null default false,
  created_at timestamptz not null default now()
);

-- Link island_items.exercise_id -> exercises.id
do $$
begin
  if not exists (
    select 1
    from information_schema.table_constraints
    where constraint_name = 'island_items_exercise_id_fkey'
  ) then
    alter table public.island_items
      add constraint island_items_exercise_id_fkey
      foreign key (exercise_id) references public.exercises(id) on delete set null;
  end if;
end $$;

-- PROGRESS: island
create table if not exists public.island_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  island_id uuid not null references public.islands(id) on delete cascade,
  completed boolean not null default false,
  points_earned int not null default 0,
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  unique (user_id, island_id)
);

-- TEST ATTEMPTS (unlimited)
create table if not exists public.section_test_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  section_id uuid not null references public.sections(id) on delete cascade,
  score_percent int not null check (score_percent >= 0 and score_percent <= 100),
  passed boolean not null default false,
  created_at timestamptz not null default now()
);

-- SECTION PROGRESS (stores recomputed totals)
create table if not exists public.section_progress (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  section_id uuid not null references public.sections(id) on delete cascade,
  completed boolean not null default false,
  best_test_score_percent int not null default 0,
  points_done int not null default 0,
  points_catchup int not null default 0,
  points_total int not null default 0,
  updated_at timestamptz not null default now(),
  unique (user_id, section_id)
);

-- EXERCISE ATTEMPTS (for later; MVP can start using this immediately)
create table if not exists public.exercise_attempts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null,
  exercise_id uuid references public.exercises(id) on delete set null,
  island_id uuid references public.islands(id) on delete set null,
  answer jsonb, -- store chosen option / numeric value / text
  is_correct boolean,
  points_awarded int not null default 0,
  time_spent_sec int not null default 0,
  created_at timestamptz not null default now()
);

-- -----------------------
-- RLS
-- -----------------------
alter table public.courses enable row level security;
alter table public.sections enable row level security;
alter table public.islands enable row level security;
alter table public.island_items enable row level security;
alter table public.exercises enable row level security;
alter table public.island_progress enable row level security;
alter table public.section_test_attempts enable row level security;
alter table public.section_progress enable row level security;
alter table public.exercise_attempts enable row level security;

-- Public readable course structure (you still require login in the app, but DB select is open)
drop policy if exists "courses_read" on public.courses;
create policy "courses_read" on public.courses for select using (true);

drop policy if exists "sections_read" on public.sections;
create policy "sections_read" on public.sections for select using (true);

drop policy if exists "islands_read" on public.islands;
create policy "islands_read" on public.islands for select using (true);

drop policy if exists "island_items_read" on public.island_items;
create policy "island_items_read" on public.island_items for select using (true);

drop policy if exists "exercises_read" on public.exercises;
create policy "exercises_read" on public.exercises for select using (true);

-- User-owned progress/attempts
drop policy if exists "island_progress_select_own" on public.island_progress;
create policy "island_progress_select_own"
on public.island_progress for select using (auth.uid() = user_id);

drop policy if exists "island_progress_upsert_own" on public.island_progress;
create policy "island_progress_upsert_own"
on public.island_progress for insert with check (auth.uid() = user_id);

drop policy if exists "island_progress_update_own" on public.island_progress;
create policy "island_progress_update_own"
on public.island_progress for update using (auth.uid() = user_id);

drop policy if exists "section_test_attempts_select_own" on public.section_test_attempts;
create policy "section_test_attempts_select_own"
on public.section_test_attempts for select using (auth.uid() = user_id);

drop policy if exists "section_test_attempts_insert_own" on public.section_test_attempts;
create policy "section_test_attempts_insert_own"
on public.section_test_attempts for insert with check (auth.uid() = user_id);

drop policy if exists "section_progress_select_own" on public.section_progress;
create policy "section_progress_select_own"
on public.section_progress for select using (auth.uid() = user_id);

drop policy if exists "section_progress_insert_own" on public.section_progress;
create policy "section_progress_insert_own"
on public.section_progress for insert with check (auth.uid() = user_id);

drop policy if exists "section_progress_update_own" on public.section_progress;
create policy "section_progress_update_own"
on public.section_progress for update using (auth.uid() = user_id);

drop policy if exists "exercise_attempts_select_own" on public.exercise_attempts;
create policy "exercise_attempts_select_own"
on public.exercise_attempts for select using (auth.uid() = user_id);

drop policy if exists "exercise_attempts_insert_own" on public.exercise_attempts;
create policy "exercise_attempts_insert_own"
on public.exercise_attempts for insert with check (auth.uid() = user_id);

-- -----------------------
-- SEED: course + sections + islands
-- -----------------------
insert into public.courses (id, title, description)
values
  ('matematyka_podstawa', 'Matematyka – Poziom podstawowy', 'Kurs przygotowujący do matury (poziom podstawowy).')
on conflict (id) do update set title = excluded.title;

-- Sections (13)
with s as (
  select *
  from (values
    (1,  'liczby-rzeczywiste',                    'Liczby rzeczywiste',                                     false),
    (2,  'wyrazenia-algebraiczne',                'Wyrażenia algebraiczne',                                 false),
    (3,  'rownania-i-nierownosci',                'Równania i nierówności',                                 false),
    (4,  'uklady-rownan',                         'Układy równań',                                          false),
    (5,  'funkcje',                               'Funkcje',                                                false),
    (6,  'ciagi',                                 'Ciągi',                                                  false),
    (7,  'trygonometria',                         'Trygonometria',                                          false),
    (8,  'planimetria',                           'Planimetria',                                            true),
    (9,  'geometria-analityczna',                 'Geometria analityczna na płaszczyźnie kartezjańskiej',   false),
    (10, 'stereometria',                          'Stereometria',                                           false),
    (11, 'kombinatoryka',                         'Kombinatoryka',                                          false),
    (12, 'prawdopodobienstwo-i-statystyka',       'Rachunek prawdopodobieństwa i statystyka',               false),
    (13, 'optymalizacja-i-rachunek-rozniczkowy',  'Optymalizacja i rachunek różniczkowy',                   false)
  ) as t(order_index, slug, title, is_free)
)
insert into public.sections (course_id, order_index, slug, title, is_free)
select 'matematyka_podstawa', s.order_index, s.slug, s.title, s.is_free
from s
on conflict (course_id, slug) do update
set title = excluded.title,
    order_index = excluded.order_index,
    is_free = excluded.is_free;

-- Islands: 5 normal + 1 test for each section
-- max_points placeholders: 200 per normal island (you can adjust later), test max_points=0
insert into public.islands (section_id, title, type, order_index, max_points)
select
  sec.id,
  case
    when i.is_test then 'Test'
    else 'Wyspa ' || i.idx::text
  end as title,
  case when i.is_test then 'test' else 'normal' end as type,
  case when i.is_test then 6 else i.idx end as order_index,
  case when i.is_test then 0 else 200 end as max_points
from public.sections sec
join (
  select 1 as idx, false as is_test union all
  select 2, false union all
  select 3, false union all
  select 4, false union all
  select 5, false union all
  select 6, true
) i on true
where sec.course_id = 'matematyka_podstawa'
on conflict do nothing;