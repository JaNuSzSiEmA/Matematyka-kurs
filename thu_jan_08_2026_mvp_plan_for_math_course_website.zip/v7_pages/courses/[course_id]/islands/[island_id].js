import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useRouter } from 'next/router';
import Link from 'next/link';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

function toEmbedUrl(youtubeUrl) {
  if (!youtubeUrl) return null;
  try {
    const url = new URL(youtubeUrl);
    if (url.hostname.includes('youtu.be')) {
      return `https://www.youtube.com/embed/${url.pathname.replace('/', '')}`;
    }
    const vid = url.searchParams.get('v');
    if (vid) return `https://www.youtube.com/embed/${vid}`;
    if (youtubeUrl.includes('/embed/')) return youtubeUrl;
    return youtubeUrl;
  } catch {
    return youtubeUrl;
  }
}

function formatUserAnswer(q) {
  if (!q?.answered) return '—';
  if (q.answer_type === 'abcd') return (q.user_answer?.choice || '—').toString().toUpperCase();
  if (q.answer_type === 'numeric') return q.user_answer?.value ?? '—';
  return '—';
}

function formatCorrectAnswer(q) {
  if (q.answer_type === 'abcd') return (q.correct_answer || '—').toString().toUpperCase();
  if (q.answer_type === 'numeric') return q.correct_answer ?? '—';
  return '—';
}

export default function IslandPage() {
  const router = useRouter();
  const { course_id, island_id } = router.query;

  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [island, setIsland] = useState(null);
  const [items, setItems] = useState([]);

  const [answers, setAnswers] = useState({}); // { [exerciseId]: { value? | choice? } }
  const [saved, setSaved] = useState({}); // { [exerciseId]: true }
  const [submittingTest, setSubmittingTest] = useState(false);
  const [testResult, setTestResult] = useState(null);

  // Built-in confirm box state (instead of window.confirm)
  const [pendingFinish, setPendingFinish] = useState(null); // { filled: number } | null

  // NEW: section rules so we can show /9 before finishing
  const [testRules, setTestRules] = useState({ test_questions_count: 6, pass_percent: 60 });

  // Map exercise_id -> perQuestion result (after submit)
  const resultByExerciseId = useMemo(() => {
    const map = new Map();
    for (const q of testResult?.perQuestion || []) {
      map.set(q.exercise_id, q);
    }
    return map;
  }, [testResult]);

  const exerciseIds = useMemo(
    () => items.filter((it) => it.item_type === 'exercise' && it.exercise?.id).map((it) => it.exercise.id),
    [items]
  );

  useEffect(() => {
    if (!course_id || !island_id) return;

    (async () => {
      setLoading(true);
      setMsg('');
      setTestResult(null);
      setPendingFinish(null);

      // clear per-island UI state (prevents “old /6” flashing)
      setSaved({});
      setAnswers({});

      const {
        data: { session },
      } = await supabase.auth.getSession();
      if (!session) {
        router.replace('/login');
        return;
      }

      const { data: isl, error: islErr } = await supabase
        .from('islands')
        .select('id, title, type, order_index, section_id, is_active')
        .eq('id', island_id)
        .single();

      if (islErr || !isl) {
        setMsg('Nie znaleziono wyspy.');
        setLoading(false);
        return;
      }
      if (isl.is_active === false) {
        setMsg('Ta wyspa jest nieaktywna.');
        setLoading(false);
        return;
      }
      setIsland(isl);

      // NEW: Load section test rules (so UI can show e.g. /9 before finishing)
      const { data: secRules, error: secRulesErr } = await supabase
        .from('sections')
        .select('id, test_questions_count, pass_percent')
        .eq('id', isl.section_id)
        .single();

      if (secRulesErr) {
        console.warn('Could not load section rules:', secRulesErr.message);
      } else if (secRules) {
        setTestRules({
          test_questions_count: Number(secRules.test_questions_count || 6),
          pass_percent: Number(secRules.pass_percent || 60),
        });
      }

      const { data: its, error: itsErr } = await supabase
        .from('island_items')
        .select('id, item_type, order_index, title, youtube_url, exercise_id')
        .eq('island_id', island_id)
        .order('order_index', { ascending: true });

      if (itsErr) {
        setMsg('Błąd pobierania elementów wyspy: ' + itsErr.message);
        setItems([]);
        setLoading(false);
        return;
      }

      // Load exercise prompts/types for items (IMPORTANT: do NOT select answer_key here)
      const exIds = (its || []).map((x) => x.exercise_id).filter(Boolean);
      let exById = {};
      if (exIds.length > 0) {
        const { data: exData, error: exErr } = await supabase
          .from('exercises')
          .select('id, prompt, answer_type, points_max')
          .in('id', exIds);

        if (exErr) {
          setMsg('Błąd pobierania zadań: ' + exErr.message);
        } else {
          exById = Object.fromEntries((exData || []).map((e) => [e.id, e]));
        }
      }

      const merged = (its || []).map((it) => ({
        ...it,
        exercise: it.exercise_id ? exById[it.exercise_id] : null,
      }));

      setItems(merged);
      setLoading(false);
    })();
  }, [course_id, island_id, router]);

  async function submitExercise(exerciseId) {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) {
      router.replace('/login');
      return;
    }

    const answer = answers[exerciseId] || {};

    const res = await fetch('/api/exercise-attempt', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${session.access_token}`,
      },
      body: JSON.stringify({
        island_id,
        exercise_id: exerciseId,
        answer,
        time_spent_sec: 0,
      }),
    });

    const json = await res.json();
    if (!res.ok) {
      setMsg(json?.error ? `${json.error}${json.details ? `: ${json.details}` : ''}` : 'Submit failed');
      return;
    }

    setSaved((prev) => ({ ...prev, [exerciseId]: true }));
    setMsg('');
  }

  async function reallySubmitTest() {
    const {
      data: { session },
    } = await supabase.auth.getSession();
    if (!session) {
      router.replace('/login');
      return;
    }

    setSubmittingTest(true);
    setMsg('');
    setTestResult(null);

    try {
      const res = await fetch('/api/submit-test', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${session.access_token}`,
        },
        body: JSON.stringify({ island_id }),
      });

      const json = await res.json();
      if (!res.ok) {
        setMsg(json?.error ? `${json.error}${json.details ? `: ${json.details}` : ''}` : 'Submit test failed');
        return;
      }

      setTestResult(json);

      // Scroll summary (bottom)
      setTimeout(() => {
        const el = document.getElementById('test-summary');
        if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
      }, 0);
    } finally {
      setSubmittingTest(false);
    }
  }

  function onClickFinishTest(testCount) {
    const filled = Object.keys(saved).length;
    if (filled < testCount) {
      setPendingFinish({ filled });
      return;
    }
    setPendingFinish(null);
    reallySubmitTest();
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-3xl p-6 text-sm text-gray-700">Ładowanie…</div>
      </div>
    );
  }

  const isTest = island?.type === 'test';
  const testCount = isTest ? (testRules?.test_questions_count ?? 6) : null;
  const passPercent = isTest ? (testRules?.pass_percent ?? 60) : null;

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-3xl p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link href="/dashboard" className="text-sm font-semibold text-gray-700 underline">
              ← Panel
            </Link>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">
              {isTest ? 'Test' : 'Wyspa'}: {island?.title}
            </h1>
            <p className="mt-1 text-sm text-gray-600">
              {isTest
                ? `Zapisz odpowiedzi, a potem zakończ test. Po zakończeniu pytania podświetlą się na zielono/czerwono. (próg: ${passPercent}%)`
                : 'Najpierw wideo, potem zadania.'}
            </p>
          </div>

          <span
            className={[
              'h-fit rounded-full px-3 py-1 text-xs font-semibold',
              isTest ? 'bg-indigo-100 text-indigo-800' : 'bg-gray-100 text-gray-800',
            ].join(' ')}
          >
            {isTest ? 'TEST' : 'NORMAL'}
          </span>
        </div>

        {msg ? (
          <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
        ) : null}

        <div className="mt-6 space-y-4">
          {items.length === 0 ? (
            <div className="rounded-2xl border border-gray-200 p-4 text-sm text-gray-700">
              Brak elementów w tej wyspie.
            </div>
          ) : (
            items.map((it) => {
              if (it.item_type === 'video') {
                return (
                  <div key={it.id} className="rounded-2xl border border-gray-200 p-4">
                    <div className="text-xs font-semibold text-gray-500">WIDEO • #{it.order_index}</div>
                    <div className="mt-1 text-base font-semibold text-gray-900">{it.title || 'Lekcja wideo'}</div>
                    <div className="mt-3 aspect-video w-full overflow-hidden rounded-xl bg-black">
                      <iframe
                        className="h-full w-full"
                        src={toEmbedUrl(it.youtube_url)}
                        title={it.title || 'YouTube video'}
                        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                        allowFullScreen
                      />
                    </div>
                  </div>
                );
              }

              const ex = it.exercise;
              const exId = ex?.id;
              const isSaved = exId ? Boolean(saved[exId]) : false;
              const a = exId ? answers[exId] || {} : {};
              const disabled = !exId;

              // If this is a test and we have results, color the question card
              const qRes = exId ? resultByExerciseId.get(exId) : null;
              const showGradingInCard = isTest && Boolean(testResult) && Boolean(qRes);

              const cardStyle = showGradingInCard
                ? !qRes.answered
                  ? 'border-gray-200 bg-white'
                  : qRes.is_correct
                    ? 'border-green-200 bg-green-50'
                    : 'border-red-200 bg-red-50'
                : 'border-gray-200 bg-white';

              const badge = showGradingInCard
                ? !qRes.answered
                  ? { text: 'BRAK', cls: 'bg-gray-100 text-gray-800 border-gray-200' }
                  : qRes.is_correct
                    ? { text: 'OK', cls: 'bg-green-100 text-green-800 border-green-200' }
                    : { text: 'BŁĄD', cls: 'bg-red-100 text-red-800 border-red-200' }
                : null;

              return (
                <div key={it.id} className={`rounded-2xl border p-4 ${cardStyle}`}>
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs font-semibold text-gray-500">ZADANIE • #{it.order_index}</div>
                      <div className="mt-1 text-base font-semibold text-gray-900">{it.title || 'Ćwiczenie'}</div>
                    </div>

                    {badge ? (
                      <span className={`rounded-full border px-2 py-1 text-xs font-semibold ${badge.cls}`}>
                        {badge.text}
                      </span>
                    ) : null}
                  </div>

                  <div className="mt-2 whitespace-pre-wrap text-sm text-gray-800">{ex?.prompt || '(brak treści)'}</div>

                  <div className="mt-3">
                    {ex?.answer_type === 'numeric' ? (
                      <input
                        className="w-full rounded-xl border border-gray-300 bg-white px-3 py-2 text-sm"
                        placeholder="Wpisz odpowiedź (liczba)"
                        value={a.value || ''}
                        onChange={(e) =>
                          setAnswers((prev) => ({
                            ...prev,
                            [exId]: { ...(prev[exId] || {}), value: e.target.value },
                          }))
                        }
                      />
                    ) : ex?.answer_type === 'abcd' ? (
                      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4">
                        {['A', 'B', 'C', 'D'].map((opt) => {
                          const selected = (a.choice || '').toUpperCase() === opt;
                          return (
                            <button
                              key={opt}
                              type="button"
                              className={[
                                'rounded-xl border px-3 py-2 text-sm font-semibold',
                                selected
                                  ? 'border-gray-900 bg-gray-900 text-white'
                                  : 'border-gray-300 bg-white text-gray-900',
                              ].join(' ')}
                              onClick={() =>
                                setAnswers((prev) => {
                                  const prevChoice = (prev?.[exId]?.choice || '').toUpperCase();
                                  const nextChoice = prevChoice === opt ? '' : opt; // toggle off
                                  return {
                                    ...prev,
                                    [exId]: { ...(prev[exId] || {}), choice: nextChoice },
                                  };
                                })
                              }
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                    ) : (
                      <div className="text-sm text-gray-600">
                        Typ zadania: <code>{ex?.answer_type}</code> (MVP jeszcze nieobsługiwane)
                      </div>
                    )}
                  </div>

                  {/* After finishing test: show correct answer inside the question card */}
                  {showGradingInCard ? (
                    <div className="mt-3 rounded-xl border border-gray-200 bg-white/70 p-3 text-sm text-gray-900">
                      <div>
                        <span className="font-semibold">Twoja odpowiedź:</span> {formatUserAnswer(qRes)}
                      </div>
                      <div className="mt-1">
                        <span className="font-semibold">Poprawna odpowiedź:</span> {formatCorrectAnswer(qRes)}
                      </div>
                      {!qRes.answered ? (
                        <div className="mt-2 text-xs text-gray-700">
                          Nie zapisano odpowiedzi — policzone jako błędne.
                        </div>
                      ) : null}
                    </div>
                  ) : null}

                  <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between">
                    <div className="text-xs text-gray-600">
                      Punkty: {ex?.points_max ?? 0}
                      {isSaved ? <span className="ml-2 font-semibold">• zapisano</span> : null}
                    </div>

                    <button
                      type="button"
                      disabled={disabled || !(ex?.answer_type === 'numeric' || ex?.answer_type === 'abcd')}
                      onClick={() => submitExercise(exId)}
                      className="rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
                    >
                      {isTest ? 'Zapisz odpowiedź' : 'Sprawdź'}
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Finish panel */}
        {isTest ? (
          <div className="mt-6 rounded-2xl border border-indigo-200 bg-indigo-50 p-4">
            <div className="text-sm text-indigo-900">
              Wypełnione: <b>{Object.keys(saved).length}</b> / {testCount} (liczone jako „zapisane”)
            </div>

            {/* Red confirm box (hidden after testResult exists) */}
            {!testResult && pendingFinish ? (
              <div className="mt-3 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-900">
                <div className="font-semibold">Nie uzupełniłeś wszystkich odpowiedzi.</div>
                <div className="mt-1">
                  Uzupełniono {pendingFinish.filled}/{testCount}. Brakujące zostaną policzone jako błędne.
                </div>
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                  <button
                    type="button"
                    className="rounded-xl border border-red-700 bg-red-700 px-4 py-2 text-sm font-semibold text-white"
                    onClick={() => {
                      setPendingFinish(null);
                      reallySubmitTest();
                    }}
                  >
                    Zakończ mimo to
                  </button>
                  <button
                    type="button"
                    className="rounded-xl border border-red-700 bg-white px-4 py-2 text-sm font-semibold text-red-700"
                    onClick={() => setPendingFinish(null)}
                  >
                    Wróć i uzupełnij
                  </button>
                </div>
              </div>
            ) : null}

            {/* Remove finish button after finishing */}
            {!testResult ? (
              <button
                type="button"
                onClick={() => onClickFinishTest(testCount)}
                disabled={submittingTest}
                className="mt-3 rounded-xl border border-indigo-700 bg-indigo-700 px-4 py-2 text-sm font-semibold text-white disabled:opacity-50"
              >
                {submittingTest ? 'Zapisuję…' : 'Zakończ test'}
              </button>
            ) : (
              <div className="mt-3 text-sm font-semibold text-indigo-900">
                Test zakończony — wynik jest zapisany poniżej.
              </div>
            )}

            <div className="mt-2 text-xs text-indigo-900/80">
              MVP: wynik liczy się z ostatnich prób każdego z {testCount} zadań. Brak odpowiedzi = 0 pkt.
            </div>
          </div>
        ) : null}

        {/* Bottom summary only */}
        {isTest && testResult ? (
          <div
            id="test-summary"
            className="mt-6 rounded-2xl border border-indigo-200 bg-indigo-50 p-4 text-sm text-indigo-900"
          >
            <div className="font-semibold">Podsumowanie</div>
            <div className="mt-1">
              Wynik: <b>{testResult.score_percent}%</b>
            </div>
            <div>
              Poprawne: {testResult.correctCount} / {testResult.test_questions_count ?? testCount}
            </div>
            <div>
              Zaliczone: {testResult.passed ? 'TAK' : 'NIE'} (próg {testResult.pass_percent ?? passPercent}%)
            </div>
            <div>Najlepszy wynik w dziale: {testResult.best_test_score_percent}%</div>
            <div className="mt-2 text-xs text-indigo-900/80">
              Przewiń w górę — zadania zostały oznaczone na zielono/czerwono.
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}