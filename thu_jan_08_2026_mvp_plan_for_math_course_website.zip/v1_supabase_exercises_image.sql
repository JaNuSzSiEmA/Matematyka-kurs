alter table public.exercises
  add column if not exists image_url text;