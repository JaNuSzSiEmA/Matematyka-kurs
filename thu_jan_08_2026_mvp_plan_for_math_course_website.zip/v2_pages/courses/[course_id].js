import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useRouter } from 'next/router';
import Link from 'next/link';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

export default function CoursePage() {
  const router = useRouter();
  const { course_id } = router.query;

  const [checking, setChecking] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const [userEmail, setUserEmail] = useState(null);
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (!course_id) return;

    (async () => {
      setChecking(true);
      setErrorMsg('');

      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) console.error('getSession error', error);

      if (!session) {
        setChecking(false);
        setHasAccess(false);
        setUserEmail(null);
        return;
      }

      setUserEmail(session.user?.email || null);

      try {
        const res = await fetch(`/api/has-access?course_id=${encodeURIComponent(course_id)}`, {
          headers: { Authorization: `Bearer ${session.access_token}` },
        });

        const json = await res.json().catch(() => ({}));

        if (!res.ok) {
          setErrorMsg(json.error || `has-access failed (HTTP ${res.status})`);
          setHasAccess(false);
        } else {
          setHasAccess(Boolean(json.access));
        }
      } catch (e) {
        setErrorMsg('Failed to call /api/has-access: ' + e.message);
        setHasAccess(false);
      } finally {
        setChecking(false);
      }
    })();
  }, [course_id]);

  if (checking) return <div style={{ padding: 24 }}>Checking access...</div>;

  if (!userEmail) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Please sign in</h1>
        <p>You must be logged in to view this course.</p>
        <Link href="/login">Go to login</Link>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div style={{ padding: 24 }}>
        <h1>Access denied</h1>
        <p>Signed in as: {userEmail}</p>
        <p>You don’t have access to this course.</p>
      </div>
    );
  }

  // ✅ Put your real course content here
  return (
    <div style={{ padding: 24 }}>
      <h1>Matematyka — Podstawa</h1>
      <p><strong>Course id:</strong> {course_id}</p>
      <p><strong>Signed in as:</strong> {userEmail}</p>

      <hr style={{ margin: '16px 0' }} />

      <h2>Lekcja 1: Wstęp</h2>
      <p>Tu wstawisz treść kursu (lekcje, linki do wideo, PDFy itd.).</p>

      <h2>Lekcja 2: Przykłady</h2>
      <ul>
        <li>Przykład 1</li>
        <li>Przykład 2</li>
      </ul>
    </div>
  );
}