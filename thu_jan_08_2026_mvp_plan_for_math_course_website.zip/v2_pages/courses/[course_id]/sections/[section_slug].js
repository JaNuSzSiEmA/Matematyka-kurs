import { useEffect, useMemo, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { useRouter } from 'next/router';
import Link from 'next/link';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

export default function SectionPathPage() {
  const router = useRouter();
  const { course_id, section_slug } = router.query;

  const [loading, setLoading] = useState(true);
  const [checkingAccess, setCheckingAccess] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);

  const [section, setSection] = useState(null);
  const [islands, setIslands] = useState([]);
  const [msg, setMsg] = useState('');

  const zigZag = useMemo(() => (idx) => (idx % 2 === 0 ? 'justify-start' : 'justify-end'), []);

  useEffect(() => {
    if (!course_id || !section_slug) return;

    (async () => {
      setLoading(true);
      setMsg('');

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.replace('/login');
        return;
      }

      const { data: sec, error: secErr } = await supabase
        .from('sections')
        .select('id, title, slug, is_free')
        .eq('course_id', course_id)
        .eq('slug', section_slug)
        .single();

      if (secErr || !sec) {
        setMsg('Nie znaleziono działu.');
        setLoading(false);
        setCheckingAccess(false);
        return;
      }
      setSection(sec);

      setCheckingAccess(true);
      if (sec.is_free) {
        setHasAccess(true);
        setCheckingAccess(false);
      } else {
        try {
          const accessToken = session.access_token;
          const res = await fetch(`/api/has-access?course_id=${encodeURIComponent(course_id)}`, {
            headers: { Authorization: `Bearer ${accessToken}` },
          });
          const json = await res.json();
          setHasAccess(Boolean(json.access));
        } catch {
          setHasAccess(false);
        } finally {
          setCheckingAccess(false);
        }
      }

      const { data: isl, error: islErr } = await supabase
        .from('islands')
        .select('id, title, type, order_index, max_points')
        .eq('section_id', sec.id)
        .order('order_index', { ascending: true });

      if (islErr) {
        setMsg('Błąd pobierania wysp: ' + islErr.message);
        setIslands([]);
      } else {
        setIslands(isl || []);
      }

      setLoading(false);
    })();
  }, [course_id, section_slug, router]);

  if (loading || checkingAccess) {
    return (
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-3xl p-6 text-sm text-gray-700">Ładowanie…</div>
      </div>
    );
  }

  if (!hasAccess) {
    return (
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-3xl p-6">
          <h1 className="text-2xl font-bold text-gray-900">Brak dostępu</h1>
          <p className="mt-2 text-sm text-gray-700">
            Nie masz dostępu do tego działu. Darmowy jest tylko dział: <b>Planimetria</b>.
          </p>
          <div className="mt-4">
            <Link
              href="/dashboard"
              className="rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
            >
              Wróć do panelu
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-3xl p-6">
        <div className="flex items-start justify-between gap-3">
          <div>
            <Link href="/dashboard" className="text-sm font-semibold text-gray-700 underline">
              ← Panel
            </Link>
            <h1 className="mt-2 text-2xl font-bold text-gray-900">{section?.title}</h1>
            <p className="mt-1 text-sm text-gray-600">
              Możesz przeskakiwać wyspy. Test można zrobić od razu (nieograniczone podejścia).
            </p>
          </div>

          {section?.is_free ? (
            <span className="h-fit rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-800">
              DARMOWE
            </span>
          ) : null}
        </div>

        {msg ? <div className="mt-4 text-sm text-red-700">{msg}</div> : null}

        <div className="mt-8 flex flex-col gap-6">
          {islands.map((island, idx) => {
            const isTest = island.type === 'test';
            return (
              <div key={island.id} className={`flex ${zigZag(idx)}`}>
                <Link
                  href={`/courses/${course_id}/islands/${island.id}`}
                  className={[
                    'w-full max-w-sm rounded-3xl border p-5 shadow-sm transition',
                    'hover:shadow-md',
                    isTest ? 'border-indigo-300 bg-indigo-50' : 'border-gray-200 bg-white',
                  ].join(' ')}
                >
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-xs font-semibold text-gray-500">
                        {isTest ? 'TEST (6 zadań)' : `WYSPA ${island.order_index}`}
                      </div>
                      <div className="mt-1 text-lg font-bold text-gray-900">{island.title}</div>
                      {!isTest ? (
                        <div className="mt-1 text-xs text-gray-600">Maks. punkty: {island.max_points}</div>
                      ) : (
                        <div className="mt-1 text-xs text-gray-600">Próg zaliczenia działu: 60%</div>
                      )}
                    </div>

                    <div className={isTest ? 'text-indigo-700' : 'text-gray-700'}>
                      <span className="text-sm font-semibold">Otwórz →</span>
                    </div>
                  </div>

                  <div className="mt-4 h-2 w-full rounded-full bg-gray-100">
                    <div className={`h-2 rounded-full ${isTest ? 'bg-indigo-400' : 'bg-gray-300'}`} style={{ width: '0%' }} />
                  </div>

                  <div className="mt-2 text-xs text-gray-600">
                    (W następnym kroku podłączymy realny postęp z island_progress.)
                  </div>
                </Link>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}