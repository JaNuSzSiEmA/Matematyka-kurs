import { useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import Link from 'next/link';
import { useRouter } from 'next/router';

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
);

export default function DashboardPage() {
  const router = useRouter();
  const courseId = 'matematyka_podstawa';

  const [loading, setLoading] = useState(true);
  const [userEmail, setUserEmail] = useState(null);
  const [sections, setSections] = useState([]);
  const [msg, setMsg] = useState('');

  useEffect(() => {
    (async () => {
      setLoading(true);
      setMsg('');

      const { data: { session } } = await supabase.auth.getSession();
      if (!session) {
        router.replace('/login');
        return;
      }

      setUserEmail(session.user?.email || null);

      const { data, error } = await supabase
        .from('sections')
        .select('id, slug, title, order_index, is_free')
        .eq('course_id', courseId)
        .order('order_index', { ascending: true });

      if (error) {
        setMsg('Błąd pobierania działów: ' + error.message);
        setSections([]);
      } else {
        setSections(data || []);
      }

      setLoading(false);
    })();
  }, [router]);

  return (
    <div className="min-h-screen bg-white">
      <div className="mx-auto max-w-4xl p-6">
        <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Panel ucznia</h1>
            <p className="text-sm text-gray-600">Zalogowany: {userEmail}</p>
          </div>

          <div className="flex gap-2">
            <Link
              href={`/courses/${courseId}`}
              className="rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
            >
              Kurs (sprawdź dostęp)
            </Link>
          </div>
        </div>

        <div className="mt-6 rounded-2xl border border-gray-200 p-4">
          <h2 className="text-lg font-semibold text-gray-900">Działy</h2>
          <p className="mt-1 text-sm text-gray-600">
            Darmowy dział: <b>Planimetria</b>. Możesz przeskakiwać wyspy i robić test od razu.
          </p>

          {loading ? (
            <div className="mt-4 text-sm text-gray-700">Ładowanie…</div>
          ) : msg ? (
            <div className="mt-4 text-sm text-red-700">{msg}</div>
          ) : (
            <ul className="mt-4 grid grid-cols-1 gap-3 sm:grid-cols-2">
              {sections.map((s) => (
                <li key={s.id} className="rounded-2xl border border-gray-200 p-4">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <div className="text-base font-semibold text-gray-900">{s.title}</div>
                      <div className="text-xs text-gray-600">/{s.slug}</div>
                    </div>
                    {s.is_free ? (
                      <span className="rounded-full bg-green-100 px-3 py-1 text-xs font-semibold text-green-800">
                        DARMOWE
                      </span>
                    ) : (
                      <span className="rounded-full bg-gray-100 px-3 py-1 text-xs font-semibold text-gray-800">
                        PŁATNE
                      </span>
                    )}
                  </div>

                  <div className="mt-3">
                    <Link
                      href={`/courses/${courseId}/sections/${s.slug}`}
                      className="inline-block rounded-xl border border-gray-900 bg-white px-4 py-2 text-sm font-semibold text-gray-900"
                    >
                      Otwórz ścieżkę
                    </Link>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}