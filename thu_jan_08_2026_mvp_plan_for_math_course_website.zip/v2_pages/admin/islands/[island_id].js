import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter } from 'next/router';
import AdminGate from '../../../components/admin/AdminGate';
import { supabase } from '../../../lib/admin';

export default function AdminIslandEditor() {
  const router = useRouter();
  const { island_id } = router.query;

  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [island, setIsland] = useState(null);
  const [items, setItems] = useState([]);

  const [exercises, setExercises] = useState([]);
  const [q, setQ] = useState('');

  // create item form
  const [newItem, setNewItem] = useState({
    item_type: 'video', // 'video' | 'exercise'
    title: '',
    youtube_url: '',
    exercise_id: '',
  });

  async function load() {
    if (!island_id) return;
    setLoading(true);
    setMsg('');

    const { data: isl, error: islErr } = await supabase
      .from('islands')
      .select('id, section_id, title, type, order_index, max_points, is_active')
      .eq('id', island_id)
      .single();

    if (islErr) {
      setMsg(islErr.message);
      setLoading(false);
      return;
    }
    setIsland(isl);

    const { data: it, error: itErr } = await supabase
      .from('island_items')
      .select('id, island_id, item_type, order_index, title, youtube_url, exercise_id, created_at')
      .eq('island_id', island_id)
      .order('order_index', { ascending: true });

    if (itErr) {
      setMsg(itErr.message);
      setItems([]);
      setLoading(false);
      return;
    }
    setItems(it || []);

    // Load exercises (for picking)
    const { data: ex, error: exErr } = await supabase
      .from('exercises')
      .select('id, prompt, answer_type, points_max, course_id')
      .order('created_at', { ascending: false })
      .limit(200);

    if (exErr) {
      setMsg(`Load exercises failed: ${exErr.message}`);
      setExercises([]);
      setLoading(false);
      return;
    }

    setExercises(ex || []);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, [island_id]);

  const filteredExercises = useMemo(() => {
    const term = q.trim().toLowerCase();
    if (!term) return exercises;
    return exercises.filter((e) => (e.prompt || '').toLowerCase().includes(term) || String(e.id).includes(term));
  }, [exercises, q]);

  async function addItem() {
    setMsg('');
    if (!island_id) return;

    const order_index = (items?.length || 0) + 1;

    if (newItem.item_type === 'video') {
      const { error } = await supabase.from('island_items').insert({
        island_id,
        item_type: 'video',
        order_index,
        title: newItem.title || null,
        youtube_url: newItem.youtube_url || null,
        exercise_id: null,
      });
      if (error) {
        setMsg(error.message);
        return;
      }
    } else {
      if (!newItem.exercise_id) {
        setMsg('Wybierz exercise_id.');
        return;
      }
      const { error } = await supabase.from('island_items').insert({
        island_id,
        item_type: 'exercise',
        order_index,
        title: newItem.title || null,
        youtube_url: null,
        exercise_id: newItem.exercise_id,
      });
      if (error) {
        setMsg(error.message);
        return;
      }
    }

    setNewItem({ item_type: 'video', title: '', youtube_url: '', exercise_id: '' });
    await load();
  }

  async function deleteItem(id) {
    setMsg('');
    const ok = window.confirm('Usunąć element?');
    if (!ok) return;

    const { error } = await supabase.from('island_items').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-5xl p-6">
          <div className="flex items-center justify-between">
            <div>
              <Link
                href={island?.section_id ? `/admin/sections/${island.section_id}/islands` : '/admin/sections'}
                className="text-sm font-semibold text-gray-700 underline"
              >
                ← Wyspy
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Zawartość wyspy</h1>
              <p className="mt-1 text-sm text-gray-600">
                {island ? (
                  <>
                    <b>{island.title}</b> • type: <code>{island.type}</code> • max_points: <code>{island.max_points}</code>
                  </>
                ) : (
                  '—'
                )}
              </p>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          {loading ? (
            <div className="mt-6 text-sm text-gray-700">Ładowanie…</div>
          ) : (
            <div className="mt-6 grid gap-4 lg:grid-cols-2">
              <div className="rounded-2xl border border-gray-200 p-4">
                <div className="font-semibold text-gray-900">Dodaj element</div>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">item_type</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={newItem.item_type}
                    onChange={(e) => setNewItem((p) => ({ ...p, item_type: e.target.value }))}
                  >
                    <option value="video">video</option>
                    <option value="exercise">exercise</option>
                  </select>
                </label>

                <label className="mt-3 block">
                  <div className="text-xs font-semibold text-gray-600">title (optional)</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={newItem.title}
                    onChange={(e) => setNewItem((p) => ({ ...p, title: e.target.value }))}
                  />
                </label>

                {newItem.item_type === 'video' ? (
                  <label className="mt-3 block">
                    <div className="text-xs font-semibold text-gray-600">youtube_url</div>
                    <input
                      className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                      placeholder="https://www.youtube.com/watch?v=..."
                      value={newItem.youtube_url}
                      onChange={(e) => setNewItem((p) => ({ ...p, youtube_url: e.target.value }))}
                    />
                  </label>
                ) : (
                  <>
                    <div className="mt-3">
                      <div className="text-xs font-semibold text-gray-600">Wybierz exercise</div>
                      <input
                        className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                        placeholder="Szukaj w prompt…"
                        value={q}
                        onChange={(e) => setQ(e.target.value)}
                      />
                      <select
                        className="mt-2 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                        value={newItem.exercise_id}
                        onChange={(e) => setNewItem((p) => ({ ...p, exercise_id: e.target.value }))}
                      >
                        <option value="">— wybierz —</option>
                        {filteredExercises.map((e) => (
                          <option key={e.id} value={e.id}>
                            {e.answer_type} • {e.points_max}pkt • {String(e.prompt || '').slice(0, 60)}
                          </option>
                        ))}
                      </select>
                    </div>
                  </>
                )}

                <button
                  type="button"
                  className="mt-4 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                  onClick={addItem}
                >
                  Dodaj element
                </button>
              </div>

              <div className="rounded-2xl border border-gray-200 p-4">
                <div className="font-semibold text-gray-900">Elementy</div>

                {items.length === 0 ? (
                  <div className="mt-3 text-sm text-gray-600">Brak elementów.</div>
                ) : (
                  <div className="mt-3 space-y-3">
                    {items.map((it) => (
                      <div key={it.id} className="rounded-xl border border-gray-200 p-3">
                        <div className="flex items-center justify-between gap-3">
                          <div className="text-sm text-gray-900">
                            <b>{it.order_index}.</b> <code>{it.item_type}</code>{' '}
                            {it.title ? <>• {it.title}</> : null}
                          </div>
                          <button
                            type="button"
                            className="rounded-lg border border-red-700 bg-red-700 px-3 py-1 text-sm font-semibold text-white"
                            onClick={() => deleteItem(it.id)}
                          >
                            Usuń
                          </button>
                        </div>

                        {it.item_type === 'video' ? (
                          <div className="mt-2 text-xs text-gray-700">
                            youtube_url: <code>{it.youtube_url || '—'}</code>
                          </div>
                        ) : (
                          <div className="mt-2 text-xs text-gray-700">
                            exercise_id: <code>{it.exercise_id || '—'}</code>
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </AdminGate>
  );
}