import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AdminGate from '../../components/admin/AdminGate';
import { supabase } from '../../lib/admin';

function getCourseLabel(c) {
  return c?.title || c?.name || c?.slug || c?.id || 'course';
}

function hintsFromTextarea(text) {
  const lines = String(text || '')
    .split('\n')
    .map((l) => l.trim())
    .filter(Boolean);
  return lines.length ? lines : null;
}

function normalizeChoice(x) {
  return String(x || '').trim().toUpperCase();
}

export default function AdminExerciseBank() {
  const [loading, setLoading] = useState(true);
  const [msg, setMsg] = useState('');

  const [courses, setCourses] = useState([]);
  const [sections, setSections] = useState([]);
  const [exercises, setExercises] = useState([]);
  const [answerKeysByExerciseId, setAnswerKeysByExerciseId] = useState({});

  const [filters, setFilters] = useState({
    course_id: '',
    topic_section_id: '',
    status: 'all',
    answer_type: 'all',
    q: '',
    use_in_course: false,
    use_in_repertory: false,
    use_in_generator: false,
    use_in_minigame: false,
  });

  // Create form defaults per your request:
  // use_in_course=false, rest=true
  const [create, setCreate] = useState({
    course_id: '',
    topic_section_id: '',
    prompt: '',
    description: '',
    image_url: '',
    answer_type: 'abcd',

    // abcd
    optionsA: '',
    optionsB: '',
    optionsC: '',
    optionsD: '',
    correct_choice: 'A',

    // numeric
    correct_numeric: '',

    points_max: 1,
    difficulty: 1,
    requires_ai: false,
    requires_photo: false,
    status: 'draft',
    solution_video_url: '',
    hints_text: '',

    use_in_course: false,
    use_in_repertory: true,
    use_in_generator: true,
    use_in_minigame: true,
  });

  async function load() {
    setLoading(true);
    setMsg('');

    const { data: courseRows, error: courseErr } = await supabase
      .from('courses')
      .select('id, title, description')
      .order('title', { ascending: true });

    if (courseErr) {
      setMsg(`Load courses failed: ${courseErr.message}`);
      setCourses([]);
      setLoading(false);
      return;
    }
    setCourses(courseRows || []);

    const defaultCourseId = create.course_id || (courseRows?.[0]?.id ? String(courseRows[0].id) : '');
    if (!create.course_id && defaultCourseId) {
      setCreate((p) => ({ ...p, course_id: defaultCourseId }));
      setFilters((p) => ({ ...p, course_id: defaultCourseId }));
    }

    const courseForSections = defaultCourseId || filters.course_id;
    if (courseForSections) {
      const { data: secRows, error: secErr } = await supabase
        .from('sections')
        .select('id, title, slug, order_index, course_id')
        .eq('course_id', String(courseForSections))
        .order('order_index', { ascending: true });

      if (secErr) {
        setMsg(`Load sections failed: ${secErr.message}`);
        setSections([]);
      } else {
        setSections(secRows || []);
        if (!create.topic_section_id && (secRows || []).length > 0) {
          setCreate((p) => ({ ...p, topic_section_id: secRows[0].id }));
        }
      }
    } else {
      setSections([]);
    }

    const { data: exData, error: exErr } = await supabase
      .from('exercises')
      .select(
        'id, course_id, topic_section_id, prompt, answer_type, points_max, difficulty, requires_ai, requires_photo, image_url, description, hints, solution_video_url, status, use_in_course, use_in_repertory, use_in_generator, use_in_minigame, created_at'
      )
      .order('created_at', { ascending: false })
      .limit(500);

    if (exErr) {
      setMsg(`Load exercises failed: ${exErr.message}`);
      setExercises([]);
      setAnswerKeysByExerciseId({});
      setLoading(false);
      return;
    }

    setExercises(exData || []);

    const ids = (exData || []).map((x) => x.id);
    if (ids.length === 0) {
      setAnswerKeysByExerciseId({});
      setLoading(false);
      return;
    }

    const { data: keyRows, error: keyErr } = await supabase
      .from('exercise_answer_keys')
      .select('exercise_id, answer_key')
      .in('exercise_id', ids);

    if (keyErr) {
      setMsg(`Load answer keys failed: ${keyErr.message}`);
      setAnswerKeysByExerciseId({});
      setLoading(false);
      return;
    }

    setAnswerKeysByExerciseId(Object.fromEntries((keyRows || []).map((k) => [k.exercise_id, k.answer_key])));
    setLoading(false);
  }

  useEffect(() => {
    load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    (async () => {
      if (!filters.course_id) return;

      const { data: secRows, error: secErr } = await supabase
        .from('sections')
        .select('id, title, slug, order_index, course_id')
        .eq('course_id', String(filters.course_id))
        .order('order_index', { ascending: true });

      if (secErr) {
        setMsg(`Load sections failed: ${secErr.message}`);
        setSections([]);
        return;
      }
      setSections(secRows || []);
      setFilters((p) => ({ ...p, topic_section_id: '' }));
    })();
  }, [filters.course_id]);

  const filtered = useMemo(() => {
    const term = filters.q.trim().toLowerCase();

    return exercises.filter((e) => {
      if (filters.course_id && String(e.course_id) !== String(filters.course_id)) return false;
      if (filters.topic_section_id && String(e.topic_section_id) !== String(filters.topic_section_id)) return false;
      if (filters.status !== 'all' && e.status !== filters.status) return false;
      if (filters.answer_type !== 'all' && e.answer_type !== filters.answer_type) return false;

      if (filters.use_in_course && !e.use_in_course) return false;
      if (filters.use_in_repertory && !e.use_in_repertory) return false;
      if (filters.use_in_generator && !e.use_in_generator) return false;
      if (filters.use_in_minigame && !e.use_in_minigame) return false;

      if (term) {
        const hay = `${e.prompt || ''}`.toLowerCase();
        if (!hay.includes(term)) return false;
      }

      return true;
    });
  }, [exercises, filters]);

  function buildAnswerKey() {
    if (create.answer_type === 'abcd') {
      const correct = normalizeChoice(create.correct_choice || 'A');
      const options = {
        A: String(create.optionsA || '').trim(),
        B: String(create.optionsB || '').trim(),
        C: String(create.optionsC || '').trim(),
        D: String(create.optionsD || '').trim(),
      };

      // require all options filled (you can relax this later)
      for (const k of ['A', 'B', 'C', 'D']) {
        if (!options[k]) return { error: `Uzupełnij treść odpowiedzi ${k}.` };
      }

      return { value: { options, correct } };
    }

    const raw = String(create.correct_numeric ?? '').trim();
    if (!raw) return { error: 'Uzupełnij poprawną odpowiedź.' };

    const n = Number(raw.replace(',', '.'));
    if (!Number.isNaN(n) && raw.match(/^-?\d+([.,]\d+)?$/)) return { value: { value: n } };
    return { value: { value: raw } };
  }

  async function createExercise() {
    setMsg('');

    if (!create.course_id) {
      setMsg('Wybierz course.');
      return;
    }
    if (!create.prompt.trim()) {
      setMsg('Prompt jest wymagany.');
      return;
    }

    const answerKey = buildAnswerKey();
    if (answerKey.error) {
      setMsg(answerKey.error);
      return;
    }

    const hints = hintsFromTextarea(create.hints_text);

    const { data: inserted, error: insErr } = await supabase
      .from('exercises')
      .insert({
        course_id: String(create.course_id),
        topic_section_id: create.topic_section_id ? String(create.topic_section_id) : null,
        prompt: create.prompt,
        description: create.description || null,
        image_url: create.image_url || null,
        answer_type: create.answer_type,
        points_max: Number(create.points_max),
        difficulty: Number(create.difficulty),
        requires_ai: Boolean(create.requires_ai),
        requires_photo: Boolean(create.requires_photo),
        status: create.status,
        solution_video_url: create.solution_video_url || null,
        hints,
        use_in_course: Boolean(create.use_in_course),
        use_in_repertory: Boolean(create.use_in_repertory),
        use_in_generator: Boolean(create.use_in_generator),
        use_in_minigame: Boolean(create.use_in_minigame),
      })
      .select('id')
      .single();

    if (insErr) {
      setMsg(insErr.message);
      return;
    }

    const { error: keyErr } = await supabase.from('exercise_answer_keys').insert({
      exercise_id: inserted.id,
      answer_key: answerKey.value,
    });

    if (keyErr) {
      setMsg(`Exercise created, but answer key insert failed: ${keyErr.message}`);
      await load();
      return;
    }

    // reset: keep flags so you can mass-enter into same categories
    setCreate((p) => ({
      ...p,
      prompt: '',
      description: '',
      image_url: '',
      solution_video_url: '',
      hints_text: '',
      points_max: 1,
      difficulty: 1,
      requires_ai: false,
      requires_photo: false,
      status: 'draft',
      answer_type: 'abcd',
      correct_choice: 'A',
      correct_numeric: '',
      optionsA: '',
      optionsB: '',
      optionsC: '',
      optionsD: '',
    }));

    await load();
  }

  async function deleteExercise(id) {
    setMsg('');
    const ok = window.confirm('Usunąć exercise? Uwaga: island_items mogą się zepsuć.');
    if (!ok) return;

    const { error } = await supabase.from('exercises').delete().eq('id', id);
    if (error) {
      setMsg(error.message);
      return;
    }
    await load();
  }

  return (
    <AdminGate>
      <div className="min-h-screen bg-white">
        <div className="mx-auto max-w-7xl p-6">
          <div className="flex items-center justify-between gap-4">
            <div>
              <Link href="/admin" className="text-sm font-semibold text-gray-700 underline">
                ← Admin
              </Link>
              <h1 className="mt-2 text-2xl font-bold text-gray-900">Exercise Bank</h1>
            </div>
          </div>

          {msg ? (
            <div className="mt-4 rounded-xl border border-red-200 bg-red-50 p-3 text-sm text-red-700">{msg}</div>
          ) : null}

          <div className="mt-6 grid gap-4 lg:grid-cols-2">
            {/* CREATE */}
            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Dodaj ćwiczenie</div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label>
                  <div className="text-xs font-semibold text-gray-600">Course</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.course_id}
                    onChange={(e) => setCreate((p) => ({ ...p, course_id: e.target.value }))}
                  >
                    <option value="">Wybierz…</option>
                    {courses.map((c) => (
                      <option key={c.id} value={String(c.id)}>
                        {getCourseLabel(c)}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">Topic (sekcja)</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.topic_section_id || ''}
                    onChange={(e) => setCreate((p) => ({ ...p, topic_section_id: e.target.value }))}
                  >
                    <option value="">(brak)</option>
                    {sections.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.order_index}. {s.title}
                      </option>
                    ))}
                  </select>
                </label>
              </div>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">Question (prompt)</div>
                <textarea
                  className="mt-1 min-h-[120px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.prompt}
                  onChange={(e) => setCreate((p) => ({ ...p, prompt: e.target.value }))}
                />
              </label>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">description (optional)</div>
                <textarea
                  className="mt-1 min-h-[70px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.description}
                  onChange={(e) => setCreate((p) => ({ ...p, description: e.target.value }))}
                />
              </label>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label>
                  <div className="text-xs font-semibold text-gray-600">answer_type</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.answer_type}
                    onChange={(e) => setCreate((p) => ({ ...p, answer_type: e.target.value }))}
                  >
                    <option value="abcd">abcd</option>
                    <option value="numeric">numeric</option>
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">status</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.status}
                    onChange={(e) => setCreate((p) => ({ ...p, status: e.target.value }))}
                  >
                    <option value="draft">draft</option>
                    <option value="published">published</option>
                    <option value="archived">archived</option>
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">points_max</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.points_max}
                    onChange={(e) => setCreate((p) => ({ ...p, points_max: e.target.value }))}
                  />
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">difficulty</div>
                  <input
                    type="number"
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={create.difficulty}
                    onChange={(e) => setCreate((p) => ({ ...p, difficulty: e.target.value }))}
                  />
                </label>
              </div>

              {/* ANSWERS */}
              <div className="mt-3 rounded-xl border border-gray-100 p-3">
                <div className="text-sm font-semibold text-gray-900">Answers</div>

                {create.answer_type === 'abcd' ? (
                  <>
                    <div className="mt-2 grid gap-2">
                      {(['A', 'B', 'C', 'D'] as const).map((opt) => (
                        <div key={opt} className="grid grid-cols-[40px_1fr_110px] items-center gap-2">
                          <div className="text-sm font-semibold text-gray-800">{opt}</div>
                          <input
                            className="w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                            placeholder={`Treść odpowiedzi ${opt}`}
                            value={
                              opt === 'A'
                                ? create.optionsA
                                : opt === 'B'
                                  ? create.optionsB
                                  : opt === 'C'
                                    ? create.optionsC
                                    : create.optionsD
                            }
                            onChange={(e) => {
                              const v = e.target.value;
                              setCreate((p) => ({
                                ...p,
                                ...(opt === 'A'
                                  ? { optionsA: v }
                                  : opt === 'B'
                                    ? { optionsB: v }
                                    : opt === 'C'
                                      ? { optionsC: v }
                                      : { optionsD: v }),
                              }));
                            }}
                          />
                          <button
                            type="button"
                            className={[
                              'rounded-xl border px-3 py-2 text-sm font-semibold',
                              create.correct_choice === opt
                                ? 'border-gray-900 bg-gray-900 text-white'
                                : 'border-gray-300 bg-white text-gray-900',
                            ].join(' ')}
                            onClick={() => setCreate((p) => ({ ...p, correct_choice: opt }))}
                          >
                            Poprawna
                          </button>
                        </div>
                      ))}
                    </div>
                  </>
                ) : (
                  <input
                    className="mt-2 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    placeholder="Poprawna odpowiedź (np. 12)"
                    value={create.correct_numeric}
                    onChange={(e) => setCreate((p) => ({ ...p, correct_numeric: e.target.value }))}
                  />
                )}
              </div>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">image_url (optional)</div>
                <input
                  className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.image_url}
                  onChange={(e) => setCreate((p) => ({ ...p, image_url: e.target.value }))}
                />
              </label>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">solution_video_url (optional)</div>
                <input
                  className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.solution_video_url}
                  onChange={(e) => setCreate((p) => ({ ...p, solution_video_url: e.target.value }))}
                />
              </label>

              <label className="mt-3 block">
                <div className="text-xs font-semibold text-gray-600">hints (one per line)</div>
                <textarea
                  className="mt-1 min-h-[90px] w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                  value={create.hints_text}
                  onChange={(e) => setCreate((p) => ({ ...p, hints_text: e.target.value }))}
                />
              </label>

              <div className="mt-3 grid gap-2">
                <div className="text-xs font-semibold text-gray-600">Flags</div>

                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.use_in_course)}
                    onChange={(e) => setCreate((p) => ({ ...p, use_in_course: e.target.checked }))}
                  />
                  use_in_course
                </label>
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.use_in_repertory)}
                    onChange={(e) => setCreate((p) => ({ ...p, use_in_repertory: e.target.checked }))}
                  />
                  use_in_repertory
                </label>
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.use_in_generator)}
                    onChange={(e) => setCreate((p) => ({ ...p, use_in_generator: e.target.checked }))}
                  />
                  use_in_generator
                </label>
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.use_in_minigame)}
                    onChange={(e) => setCreate((p) => ({ ...p, use_in_minigame: e.target.checked }))}
                  />
                  use_in_minigame
                </label>
              </div>

              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.requires_ai)}
                    onChange={(e) => setCreate((p) => ({ ...p, requires_ai: e.target.checked }))}
                  />
                  requires_ai
                </label>

                <label className="flex items-center gap-2 text-sm text-gray-700">
                  <input
                    type="checkbox"
                    checked={Boolean(create.requires_photo)}
                    onChange={(e) => setCreate((p) => ({ ...p, requires_photo: e.target.checked }))}
                  />
                  requires_photo
                </label>
              </div>

              <button
                type="button"
                className="mt-4 rounded-xl border border-gray-900 bg-gray-900 px-4 py-2 text-sm font-semibold text-white"
                onClick={createExercise}
              >
                Dodaj do banku
              </button>
            </div>

            {/* LIST */}
            <div className="rounded-2xl border border-gray-200 p-4">
              <div className="font-semibold text-gray-900">Ćwiczenia</div>

              {/* (List + filters kept from previous file; unchanged in spirit) */}
              <div className="mt-3 grid gap-3 sm:grid-cols-2">
                <label>
                  <div className="text-xs font-semibold text-gray-600">Course</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={filters.course_id}
                    onChange={(e) => setFilters((p) => ({ ...p, course_id: e.target.value }))}
                  >
                    <option value="">(all)</option>
                    {courses.map((c) => (
                      <option key={c.id} value={String(c.id)}>
                        {getCourseLabel(c)}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">Topic</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={filters.topic_section_id}
                    onChange={(e) => setFilters((p) => ({ ...p, topic_section_id: e.target.value }))}
                    disabled={!filters.course_id}
                  >
                    <option value="">(all)</option>
                    {sections.map((s) => (
                      <option key={s.id} value={s.id}>
                        {s.order_index}. {s.title}
                      </option>
                    ))}
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">status</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={filters.status}
                    onChange={(e) => setFilters((p) => ({ ...p, status: e.target.value }))}
                  >
                    <option value="all">(all)</option>
                    <option value="draft">draft</option>
                    <option value="published">published</option>
                    <option value="archived">archived</option>
                  </select>
                </label>

                <label>
                  <div className="text-xs font-semibold text-gray-600">answer_type</div>
                  <select
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={filters.answer_type}
                    onChange={(e) => setFilters((p) => ({ ...p, answer_type: e.target.value }))}
                  >
                    <option value="all">(all)</option>
                    <option value="abcd">abcd</option>
                    <option value="numeric">numeric</option>
                  </select>
                </label>

                <label className="sm:col-span-2">
                  <div className="text-xs font-semibold text-gray-600">Szukaj w prompt</div>
                  <input
                    className="mt-1 w-full rounded-xl border border-gray-300 px-3 py-2 text-sm"
                    value={filters.q}
                    onChange={(e) => setFilters((p) => ({ ...p, q: e.target.value }))}
                  />
                </label>
              </div>

              {loading ? (
                <div className="mt-4 text-sm text-gray-700">Ładowanie…</div>
              ) : filtered.length === 0 ? (
                <div className="mt-4 text-sm text-gray-700">Brak wyników.</div>
              ) : (
                <div className="mt-4 space-y-3">
                  {filtered.map((e) => {
                    const key = answerKeysByExerciseId[e.id];
                    let keyLabel = '';
                    if (e.answer_type === 'abcd') {
                      const correct = (key?.correct || '—').toString().toUpperCase();
                      const opts = key?.options || {};
                      keyLabel = `correct: ${correct} • A:${opts.A ?? '—'} B:${opts.B ?? '—'} C:${opts.C ?? '—'} D:${opts.D ?? '—'}`;
                    } else {
                      keyLabel = `value: ${key?.value ?? '—'}`;
                    }

                    return (
                      <div key={e.id} className="rounded-xl border border-gray-200 p-3">
                        <div className="flex items-start justify-between gap-3">
                          <div className="text-sm text-gray-900">
                            <div className="font-semibold">
                              {e.status} • {e.answer_type} • {e.points_max}pkt • diff {e.difficulty}
                            </div>
                            <div className="mt-1 text-xs text-gray-600">{keyLabel}</div>
                          </div>

                          <button
                            type="button"
                            className="rounded-lg border border-red-700 bg-red-700 px-3 py-1 text-sm font-semibold text-white"
                            onClick={() => deleteExercise(e.id)}
                          >
                            Usuń
                          </button>
                        </div>

                        <div className="mt-2 line-clamp-3 whitespace-pre-wrap text-sm text-gray-800">
                          {e.prompt || '(brak prompt)'}
                        </div>

                        <div className="mt-1 text-[11px] text-gray-500">
                          id: <code>{e.id}</code>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </AdminGate>
  );
}