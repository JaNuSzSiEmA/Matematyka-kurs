insert into public.admins (user_id)
values ('YOUR_AUTH_USER_UUID_HERE')
on conflict (user_id) do nothing;