-- Enable RLS
alter table public.sections enable row level security;
alter table public.islands enable row level security;
alter table public.island_items enable row level security;
alter table public.exercises enable row level security;

-- Read policies:
-- Everyone authenticated can read active learning content.
-- (Admins can read everything.)

-- sections
drop policy if exists "sections read" on public.sections;
create policy "sections read"
on public.sections
for select
to authenticated
using (true);

-- islands
drop policy if exists "islands read" on public.islands;
create policy "islands read"
on public.islands
for select
to authenticated
using (is_active = true OR public.is_admin(auth.uid()));

-- island_items
drop policy if exists "island_items read" on public.island_items;
create policy "island_items read"
on public.island_items
for select
to authenticated
using (true);

-- exercises (IMPORTANT: do not expose answer_key via client selects)
drop policy if exists "exercises read" on public.exercises;
create policy "exercises read"
on public.exercises
for select
to authenticated
using (true);

-- Write policies: admin only
drop policy if exists "sections admin write" on public.sections;
create policy "sections admin write"
on public.sections
for insert
to authenticated
with check (public.is_admin(auth.uid()));
create policy "sections admin update"
on public.sections
for update
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));
create policy "sections admin delete"
on public.sections
for delete
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "islands admin write" on public.islands;
create policy "islands admin insert"
on public.islands
for insert
to authenticated
with check (public.is_admin(auth.uid()));
create policy "islands admin update"
on public.islands
for update
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));
create policy "islands admin delete"
on public.islands
for delete
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "island_items admin write" on public.island_items;
create policy "island_items admin insert"
on public.island_items
for insert
to authenticated
with check (public.is_admin(auth.uid()));
create policy "island_items admin update"
on public.island_items
for update
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));
create policy "island_items admin delete"
on public.island_items
for delete
to authenticated
using (public.is_admin(auth.uid()));

drop policy if exists "exercises admin write" on public.exercises;
create policy "exercises admin insert"
on public.exercises
for insert
to authenticated
with check (public.is_admin(auth.uid()));
create policy "exercises admin update"
on public.exercises
for update
to authenticated
using (public.is_admin(auth.uid()))
with check (public.is_admin(auth.uid()));
create policy "exercises admin delete"
on public.exercises
for delete
to authenticated
using (public.is_admin(auth.uid()));