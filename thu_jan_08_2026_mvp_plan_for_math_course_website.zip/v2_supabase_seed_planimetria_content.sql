-- Seed minimal content for the FREE section: Planimetria
-- Assumptions:
-- - course_id = 'matematyka_podstawa'
-- - section slug = 'planimetria'
-- - section already has islands with order_index 1..6 (6 is test)

do $$
declare
  v_course_id text := 'matematyka_podstawa';
  v_section_id uuid;
  v_island1 uuid;
  v_island2 uuid;
  v_island3 uuid;
  v_island4 uuid;
  v_island5 uuid;
  v_island6 uuid;

  ex_id uuid;
begin
  select id into v_section_id
  from public.sections
  where course_id = v_course_id and slug = 'planimetria'
  limit 1;

  if v_section_id is null then
    raise exception 'Section "planimetria" not found. Did you seed sections first?';
  end if;

  select id into v_island1 from public.islands where section_id = v_section_id and order_index = 1 limit 1;
  select id into v_island2 from public.islands where section_id = v_section_id and order_index = 2 limit 1;
  select id into v_island3 from public.islands where section_id = v_section_id and order_index = 3 limit 1;
  select id into v_island4 from public.islands where section_id = v_section_id and order_index = 4 limit 1;
  select id into v_island5 from public.islands where section_id = v_section_id and order_index = 5 limit 1;
  select id into v_island6 from public.islands where section_id = v_section_id and order_index = 6 limit 1;

  if v_island6 is null then
    raise exception 'Expected 6 islands for planimetria (order_index 1..6). Not found.';
  end if;

  -- Rename islands
  update public.islands set title = 'Wstęp', type = 'normal' where id = v_island1;
  update public.islands set title = 'Trójkąty', type = 'normal' where id = v_island2;
  update public.islands set title = 'Wielokąty', type = 'normal' where id = v_island3;
  update public.islands set title = 'Okręgi', type = 'normal' where id = v_island4;
  update public.islands set title = 'Wielokąty foremne', type = 'normal' where id = v_island5;
  update public.islands set title = 'Test końcowy', type = 'test' where id = v_island6;

  -- Clear items for re-run
  delete from public.island_items where island_id in (v_island1, v_island2, v_island3, v_island4, v_island5, v_island6);

  -- Island 1 videos
  insert into public.island_items (island_id, item_type, order_index, title, youtube_url)
  values
    (v_island1, 'video', 1, 'Wideo 1: Wstęp do planimetrii', 'https://youtu.be/4EHXaYngepw?si=IDsF1r5bwnzvVuwU'),
    (v_island1, 'video', 2, 'Wideo 2: Podstawowe pojęcia', 'https://youtu.be/_TcejNcaFDU?si=pw2gdUJ3mIAJAZYS');

  -- Island 1 exercises (3)
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Proste: Ile wynosi suma kątów w trójkącie?',
    'numeric',
    jsonb_build_object('value', 180),
    1, 80
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island1, 'exercise', 3, 'Suma kątów w trójkącie', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'ABCD: Które zdanie jest prawdziwe? (placeholder)',
    'abcd',
    jsonb_build_object('correct', 'B', 'options', jsonb_build_array('A', 'B', 'C', 'D')),
    1, 80
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island1, 'exercise', 4, 'Pytanie ABCD (placeholder)', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Proste: Pole kwadratu o boku 5 wynosi:',
    'numeric',
    jsonb_build_object('value', 25),
    1, 80
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island1, 'exercise', 5, 'Pole kwadratu', ex_id);

  -- Island 2 (2 exercises)
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Trójkąty: W trójkącie prostokątnym o przyprostokątnych 3 i 4 przeciwprostokątna ma długość:',
    'numeric',
    jsonb_build_object('value', 5),
    2, 100
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island2, 'exercise', 1, 'Tw. Pitagorasa (3-4-5)', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Trójkąty: Jeżeli dwa kąty w trójkącie mają miary 50° i 60°, to trzeci ma:',
    'numeric',
    jsonb_build_object('value', 70),
    2, 100
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island2, 'exercise', 2, 'Trzeci kąt w trójkącie', ex_id);

  -- Island 3 (2 exercises)
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Wielokąty: Suma kątów wewnętrznych w czworokącie wynosi:',
    'numeric',
    jsonb_build_object('value', 360),
    2, 100
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island3, 'exercise', 1, 'Suma kątów w czworokącie', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Wielokąty: Ile przekątnych ma pięciokąt?',
    'numeric',
    jsonb_build_object('value', 5),
    2, 100
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island3, 'exercise', 2, 'Przekątne w pięciokącie', ex_id);

  -- Island 4 (1 open exercise)
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Okręgi: Długość okręgu o promieniu 3 to (podaj w postaci z π):',
    'open',
    jsonb_build_object('example', '2πr = 6π'),
    3, 120
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island4, 'exercise', 1, 'Obwód okręgu (otwarte)', ex_id);

  -- Island 5 (1 numeric exercise)
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id,
    'Wielokąty foremne: Ile stopni ma kąt wewnętrzny w sześciokącie foremnym?',
    'numeric',
    jsonb_build_object('value', 120),
    3, 120
  ) returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id)
  values (v_island5, 'exercise', 1, 'Kąt w sześciokącie foremnym', ex_id);

  -- TEST: exactly 6 exercises
  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 1/6: Ile wynosi suma kątów w trójkącie?', 'numeric', jsonb_build_object('value', 180), 3, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 1, 'Test: suma kątów', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 2/6 (ABCD placeholder): Wskaż poprawną odpowiedź.', 'abcd', jsonb_build_object('correct', 'C', 'options', jsonb_build_array('A','B','C','D')), 3, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 2, 'Test: ABCD', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 3/6: Pole koła o promieniu 2 wynosi (podaj w postaci z π):', 'open', jsonb_build_object('example', 'πr^2 = 4π'), 4, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 3, 'Test: pole koła (otwarte)', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 4/6: Ile przekątnych ma sześciokąt?', 'numeric', jsonb_build_object('value', 9), 4, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 4, 'Test: przekątne', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 5/6: W trójkącie prostokątnym o przyprostokątnych 6 i 8 przeciwprostokątna ma długość:', 'numeric', jsonb_build_object('value', 10), 4, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 5, 'Test: Pitagoras', ex_id);

  insert into public.exercises (course_id, section_id, prompt, answer_type, answer_key, difficulty, points_max)
  values (v_course_id, v_section_id, 'TEST 6/6 (ABCD placeholder): Wybierz poprawną odpowiedź.', 'abcd', jsonb_build_object('correct', 'A', 'options', jsonb_build_array('A','B','C','D')), 4, 150)
  returning id into ex_id;
  insert into public.island_items (island_id, item_type, order_index, title, exercise_id) values (v_island6, 'exercise', 6, 'Test: ABCD 2', ex_id);

  -- Update max_points to match rough sums (optional but helpful for catch-up)
  update public.islands set max_points = 240 where id = v_island1;
  update public.islands set max_points = 200 where id = v_island2;
  update public.islands set max_points = 200 where id = v_island3;
  update public.islands set max_points = 120 where id = v_island4;
  update public.islands set max_points = 120 where id = v_island5;

end $$;