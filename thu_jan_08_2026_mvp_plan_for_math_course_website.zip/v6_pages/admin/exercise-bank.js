// ADD this import with the others at the top:
import { useRouter } from 'next/router';

// ...inside AdminExerciseBank() component, near other hooks/state:
const router = useRouter();
const focusedExerciseId = router.query.exercise_id ? String(router.query.exercise_id) : '';

// ...add this useEffect anywhere inside the component (after hooks are defined):
useEffect(() => {
  if (!focusedExerciseId) return;
  const el = document.getElementById(`exercise-card-${focusedExerciseId}`);
  if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
}, [focusedExerciseId, loading]);

// ...and in the EDIT LIST map, change the wrapper div for each exercise card from:
<div key={e.id} className="rounded-xl border border-gray-200 p-3">

// to:
<div
  key={e.id}
  id={`exercise-card-${e.id}`}
  className={[
    'rounded-xl border p-3',
    focusedExerciseId === String(e.id) ? 'border-indigo-400 bg-indigo-50' : 'border-gray-200',
  ].join(' ')}
>