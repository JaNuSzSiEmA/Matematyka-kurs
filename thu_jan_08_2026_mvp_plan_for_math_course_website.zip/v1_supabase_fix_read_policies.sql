-- Ensure RLS is enabled (safe if already enabled)
alter table public.courses enable row level security;
alter table public.sections enable row level security;
alter table public.islands enable row level security;
alter table public.island_items enable row level security;
alter table public.exercises enable row level security;

-- Drop & recreate read policies (public read)
drop policy if exists "courses_read" on public.courses;
create policy "courses_read" on public.courses
for select using (true);

drop policy if exists "sections_read" on public.sections;
create policy "sections_read" on public.sections
for select using (true);

drop policy if exists "islands_read" on public.islands;
create policy "islands_read" on public.islands
for select using (true);

drop policy if exists "island_items_read" on public.island_items;
create policy "island_items_read" on public.island_items
for select using (true);

drop policy if exists "exercises_read" on public.exercises;
create policy "exercises_read" on public.exercises